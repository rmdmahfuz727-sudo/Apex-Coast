// Renders the hero car frame used behind the launcher icon: node tools/icon-art.js [outDir] [car]
// Needs playwright. Output: <outDir>/art-<n>.png (1080 x 1080) for a few camera angles.
const { chromium } = require('playwright');
const path = require('path');
const root = path.resolve(__dirname, '..');
const OUT = path.resolve(process.argv[2] || path.join(root, 'branding', 'src'));
const CAR = process.argv[3] || 'ember';
const URL = 'file://' + path.join(root, 'android/app/src/main/assets/index.html');
const ARGS = ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'];
const ANGLES = {
  a: { off: [-3.0, 0.95, -4.3], look: [0.2, 0.55, 0.2], fov: 40 },
  b: { off: [-2.2, 0.8, -3.6], look: [0.4, 0.5, -0.2], fov: 44 },
  c: { off: [3.0, 0.9, -4.0], look: [-0.2, 0.55, 0.0], fov: 40 },
  d: { off: [-4.2, 1.1, 3.4], look: [0, 0.6, 0], fov: 38 },
};
(async () => {
  const b = await chromium.launch({ args: ARGS });
  for (const [n, a] of Object.entries(ANGLES)) {
    const ctx = await b.newContext({ viewport: { width: 540, height: 540 }, deviceScaleFactor: 2, hasTouch: true, isMobile: true });
    await ctx.addInitScript(([car]) => {
      try { localStorage.setItem('apexcoast.v1', JSON.stringify({ set: { q: 'high', fps: 60, music: 0, sfx: 0, auto: 1, shake: 1, tod: 'sunset', mb: 0 }, credits: 1, best: 1, owned: ['vesper', 'ember', 'mamba', 'solstice'], sel: car })); } catch (e) {}
    }, [CAR]);
    const page = await ctx.newPage();
    await page.route('**/*', r => (r.request().url().startsWith('file:') ? r.continue() : r.abort()));
    await page.goto(URL);
    await page.waitForTimeout(2600);
    await page.evaluate(() => __ac.startRun());
    await page.waitForTimeout(3600);
    await page.evaluate(([a]) => {
      __ac.pauseGame(); show(null);
      document.getElementById('hud').classList.remove('on');
      document.getElementById('touch').classList.remove('on');
      __ac.TR.forEach(t => { t.car.group.visible = false; });
      const p = player.group.position;
      camera.position.set(p.x + a.off[0], p.y + a.off[1], p.z + a.off[2]);
      camera.lookAt(p.x + a.look[0], p.y + a.look[1], p.z + a.look[2]); camera.fov = a.fov; camera.updateProjectionMatrix();
    }, [a]);
    await page.waitForTimeout(500);
    await page.screenshot({ path: path.join(OUT, `art-${n}.png`) });
    console.log('art', n);
    await ctx.close();
  }
  await b.close();
})();
