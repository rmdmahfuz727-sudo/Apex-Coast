// Builds the app icon from the hero car frame (branding/src/icon-art.png, made by tools/icon-art.js).
//   node tools/make-icon.js
// Writes the adaptive-icon layers (android res/drawable-nodpi/ic_bg.png + ic_fg.png), the Play icon (store/icon-512.png)
// and a rounded preview (branding/apex-coast-icon-1024.png). Layers are 432 px = 108 dp at xxxhdpi.
const { chromium } = require('playwright');
const fs = require('fs'), path = require('path');
const root = path.resolve(__dirname, '..');
const art = fs.readFileSync(path.join(root, 'branding/src/icon-art.png')).toString('base64');
const word = fs.readFileSync(path.join(root, 'branding/apex-coast-wordmark.svg'), 'utf8').replace(/width="[^"]+"\s+height="[^"]+"/, 'width="238"');
const mark = fs.readFileSync(path.join(root, 'branding/apex-coast-mark.svg'), 'utf8').replace(/width="[^"]+"\s+height="[^"]+"/, 'width="74" height="74"');
const RES = path.join(root, 'android/app/src/main/res');
const N = 432;

// background layer: hero frame, sky shaded darker behind the title, cream swoosh panel bottom-right
const BG = `<div style="position:relative;width:${N}px;height:${N}px;overflow:hidden;background:#140A24">
  <img src="data:image/png;base64,${art}" style="position:absolute;left:-26px;top:-4px;width:${N * 1.12}px;height:${N * 1.12}px">
  <div style="position:absolute;inset:0;background:linear-gradient(180deg,rgba(24,8,44,.48) 0%,rgba(24,8,44,.22) 30%,rgba(24,8,44,0) 52%),linear-gradient(0deg,rgba(20,10,36,.45),rgba(20,10,36,0) 30%)"></div>
  <svg viewBox="0 0 ${N} ${N}" width="${N}" height="${N}" style="position:absolute;inset:0">
    <defs><linearGradient id="pn" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFFFFF"/><stop offset="1" stop-color="#FFE9D2"/></linearGradient></defs>
    <path d="M${N} 232 C 376 242 304 292 248 ${N} L ${N} ${N} Z" fill="url(#pn)"/>
  </svg></div>`;
// foreground layer: title (inside the 66 dp safe zone) and the emblem on the panel
const FG = `<div style="position:relative;width:${N}px;height:${N}px">
  <div style="position:absolute;left:${(N - 238) / 2}px;top:70px;filter:drop-shadow(0 3px 5px rgba(20,6,40,.65)) drop-shadow(0 0 14px rgba(20,6,40,.45))">${word}</div>
  <div style="position:absolute;left:318px;top:322px;filter:drop-shadow(0 2px 4px rgba(60,20,70,.35))">${mark}</div></div>`;
const html = (inner, bg) => `<body style="margin:0;background:${bg}">${inner}</body>`;

(async () => {
  const b = await chromium.launch();
  const shot = async (inner, bg, dsf, out, transparent, size = N) => {
    const ctx = await b.newContext({ viewport: { width: N, height: N }, deviceScaleFactor: dsf });
    const p = await ctx.newPage();
    await p.setContent(html(inner, bg));
    await p.waitForTimeout(300);
    await p.screenshot({ path: out, omitBackground: transparent, clip: { x: 0, y: 0, width: N, height: N } });
    await ctx.close();
    console.log('wrote', path.relative(root, out));
  };
  fs.mkdirSync(path.join(RES, 'drawable-nodpi'), { recursive: true });
  await shot(BG, '#140A24', 1, path.join(RES, 'drawable-nodpi/ic_bg.png'), false);
  await shot(FG, 'transparent', 1, path.join(RES, 'drawable-nodpi/ic_fg.png'), true);
  const both = `<div style="position:relative;width:${N}px;height:${N}px">${BG}<div style="position:absolute;inset:0">${FG}</div></div>`;
  await shot(both, '#140A24', 512 / N, path.join(root, 'store/icon-512.png'), false);
  // rounded preview like a launcher / store tile
  const prev = `<div style="width:${N}px;height:${N}px;border-radius:26%;overflow:hidden;position:relative">${both}</div>`;
  await shot(prev, 'transparent', 1024 / N, path.join(root, 'branding/apex-coast-icon-1024.png'), true);
  await b.close();
})();
