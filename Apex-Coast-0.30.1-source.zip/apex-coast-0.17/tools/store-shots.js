// Captures Google Play screenshots and the feature graphic from the built game.
//   python3 tools/build-web.py && node tools/store-shots.js
// Needs `playwright` (Chromium). Output goes to store/ (screenshots are 1920x1080, landscape 16:9).
const { chromium } = require('playwright');
const fs = require('fs'), path = require('path');
const root = path.resolve(__dirname, '..');
const OUT = path.join(root, 'store');
const URL = 'file://' + path.join(root, 'android/app/src/main/assets/index.html');
fs.mkdirSync(path.join(OUT, 'screenshots'), { recursive: true });

const OWNED = ['vesper', 'kestrel', 'ember', 'mirage', 'mamba', 'halcyon', 'solstice'];
const SHOTS = [
  { n: '1-menu', car: 'ember', tod: 'sunset', act: 'menu' },
  { n: '2-drive-day', car: 'mamba', tod: 'day', act: 'run', wait: 5200 },
  { n: '3-garage', car: 'solstice', tod: 'sunset', act: 'garage', view: 'mamba' },
  { n: '4-drive-sunset', car: 'ember', tod: 'sunset', act: 'run', wait: 5600, nitro: true },
  { n: '5-drive-night', car: 'solstice', tod: 'night', act: 'run', wait: 5200 },
  { n: '6-halcyon-dusk', car: 'halcyon', tod: 'sunset', act: 'run', wait: 5000 },
];
const ARGS = ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'];

async function open(b, w, h, car, tod) {
  const ctx = await b.newContext({ viewport: { width: w, height: h }, deviceScaleFactor: 2, hasTouch: true, isMobile: true });
  await ctx.addInitScript(([car, tod, owned]) => {
    try {
      localStorage.setItem('apexcoast.v1', JSON.stringify({
        set: { q: 'high', fps: 60, music: 0, sfx: 0, auto: 1, shake: 1, tod, mb: 1 },
        credits: 48250, best: 18420, runs: 41, far: 9200, owned, sel: car, name: 'Mahfuz',
        mb: { coast: 18420, time: 6200, rush: 3100 }
      }));
    } catch (e) {}
  }, [car, tod, OWNED]);
  const page = await ctx.newPage();
  await page.route('**/*', r => (r.request().url().startsWith('file:') ? r.continue() : r.abort()));
  await page.goto(URL);
  await page.waitForTimeout(2600);
  return { ctx, page };
}

(async () => {
  const b = await chromium.launch({ args: ARGS });
  for (const s of SHOTS) {
    const { ctx, page } = await open(b, 960, 540, s.car, s.tod);
    if (s.act === 'run') {
      await page.evaluate(() => __ac.startRun());
      await page.waitForTimeout(s.wait);
      if (s.nitro) await page.evaluate(() => { __ac.GM.nitroOn = true; __ac.GM.nitro = 1; });
      await page.waitForTimeout(900);
    } else if (s.act === 'garage') {
      await page.evaluate(v => { __ac.toGarage(); previewCar(v); }, s.view);
      await page.waitForTimeout(1800);
    }
    await page.screenshot({ path: path.join(OUT, 'screenshots', s.n + '.png') });
    console.log('shot', s.n);
    await ctx.close();
  }

  // feature graphic: hero frame from the game + logo and tagline, 1024x500
  const { ctx, page } = await open(b, 512, 250, 'mamba', 'sunset');
  await page.evaluate(() => __ac.startRun());
  await page.waitForTimeout(3600);
  await page.evaluate(() => {
    __ac.pauseGame(); show(null);
    document.getElementById('hud').classList.remove('on');
    document.getElementById('touch').classList.remove('on');
    __ac.TR.forEach(t => { t.car.group.visible = false; });
    const p = player.group.position;
    camera.position.set(p.x - 3.6, p.y + 1.15, p.z - 5.6); camera.lookAt(p.x + 3.7, p.y + .7, p.z); camera.fov = 44; camera.updateProjectionMatrix();
  });
  await page.waitForTimeout(500);
  const hero = path.join(OUT, '_hero.png');
  await page.screenshot({ path: hero });
  await ctx.close();
  const logo = fs.readFileSync(path.join(root, 'branding/apex-coast-logo-horizontal.svg'), 'utf8').replace(/width="[^"]+"\s+height="[^"]+"/, 'width="430"');
  const c2 = await b.newContext({ viewport: { width: 1024, height: 500 } });
  const p2 = await c2.newPage();
  await p2.setContent(`<body style="margin:0;width:1024px;height:500px;position:relative;overflow:hidden;background:#140A24;font-family:Inter,Arial,sans-serif">
    <img src="data:image/png;base64,${fs.readFileSync(hero).toString('base64')}" style="position:absolute;inset:0;width:1024px;height:500px;object-fit:cover">
    <div style="position:absolute;inset:0;background:linear-gradient(90deg,rgba(20,10,36,.92) 0%,rgba(20,10,36,.72) 36%,rgba(20,10,36,0) 64%),linear-gradient(0deg,rgba(20,10,36,.55),rgba(20,10,36,0) 40%)"></div>
    <div style="position:absolute;left:54px;top:132px">${logo}
      <div style="margin:22px 0 0 4px;color:#fff;font:800 italic 25px/1.25 Inter,Arial,sans-serif;letter-spacing:.01em;text-shadow:0 3px 14px rgba(0,0,0,.5)">Race the endless coast.<br><span style="color:#FFC247">Chase the sunset.</span></div>
    </div></body>`);
  await p2.waitForTimeout(400);
  await p2.screenshot({ path: path.join(OUT, 'feature-graphic-1024x500.png') });
  fs.unlinkSync(hero);
  console.log('feature graphic');
  await b.close();
})();
