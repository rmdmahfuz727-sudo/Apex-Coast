#!/usr/bin/env python3
"""Convert game/assets/source/free_racing_car_in_3_styles.glb into game/src/02c-models.html.

The GLB (CC-BY-4.0, Mena Studios) holds three cars that colour themselves from a small palette
texture. This tool bakes each triangle's palette colour into vertex colours (so the game needs no
textures), splits every car into paint / trim / head / tail / outline parts and four wheels, rotates
the cars to the game's frame (front is -z), and packs the geometry as base64 typed arrays.

    python3 tools/glb-to-cars.py
"""
import base64, colorsys, json, math, pathlib, struct, sys
import numpy as np
from PIL import Image
import io
from collections import Counter

root = pathlib.Path(__file__).resolve().parent.parent
src = root / "game" / "assets" / "source" / "free_racing_car_in_3_styles.glb"
out = root / "game" / "src" / "02c-models.html"

d = src.read_bytes()
jl = struct.unpack("<I", d[12:16])[0]
J = json.loads(d[20:20 + jl])
BIN = 20 + jl + 8

def view(i):
    bv = J["bufferViews"][i]
    o = BIN + bv.get("byteOffset", 0)
    return d[o:o + bv["byteLength"]]

def acc(i):
    a = J["accessors"][i]
    bv = J["bufferViews"][a["bufferView"]]
    n = {"SCALAR": 1, "VEC2": 2, "VEC3": 3}[a["type"]]
    dt = {5126: "<f4", 5125: "<u4", 5123: "<u2"}[a["componentType"]]
    o = BIN + bv.get("byteOffset", 0) + a.get("byteOffset", 0)
    return np.frombuffer(d, dtype=dt, count=a["count"] * n, offset=o).reshape(a["count"], n)

PAL = np.array(Image.open(io.BytesIO(view(J["images"][1]["bufferView"]))).convert("RGB"))

def sample(uv):
    x = np.clip((uv[:, 0] * 256).astype(int), 0, 255)
    y = np.clip((uv[:, 1] * 256).astype(int), 0, 255)
    return PAL[y, x].astype(np.float64)

def mesh_data(mi):
    pr = J["meshes"][mi]["primitives"][0]
    at = pr["attributes"]
    return acc(at["POSITION"]).astype(np.float64), acc(at["NORMAL"]).astype(np.float64), \
        acc(at["TEXCOORD_0"]).astype(np.float64), acc(pr["indices"]).reshape(-1, 3).astype(np.int64)

def node_matrix(n):
    m = np.eye(4)
    if "matrix" in n:
        m = np.array(n["matrix"], dtype=np.float64).reshape(4, 4).T
    return m

def luma(c):
    return 0.2126 * c[..., 0] + 0.7152 * c[..., 1] + 0.0722 * c[..., 2]

def is_paint(c):
    h, s, v = colorsys.rgb_to_hsv(*(np.array(c) / 255.0))
    return s > 0.45 and v > 0.25

def to_game(p, s):
    """GLB car space (front +z) to game space (front -z), metres."""
    q = p * s
    q[:, 0] *= -1
    q[:, 2] *= -1
    return q

def to_game_n(n):
    n = n.copy()
    n[:, 0] *= -1
    n[:, 2] *= -1
    return n

def build_part(P, N, tris, tricol, s, shade=None, flat=False):
    """Indexed part where every triangle keeps its own palette colour (vertices split on colour)."""
    keys, vp, vn, vc, idx = {}, [], [], [], []
    for t, col in zip(tris, tricol):
        cc = tuple(int(round(x)) for x in col)
        for v in t:
            k = (int(v), cc)
            if k not in keys:
                keys[k] = len(vp)
                vp.append(P[v]); vn.append(N[v]); vc.append(col)
            idx.append(keys[k])
    vp = to_game(np.array(vp), s)
    vn = to_game_n(np.array(vn))
    vc = np.array(vc)
    if shade is not None:
        vc = np.repeat(shade(vc)[:, None], 3, axis=1) * 255
    return pack(vp, vn, vc, np.array(idx))

def pack(vp, vn, vc, idx):
    pq = np.round(vp * 3000).astype("<i2")
    nq = np.round(np.clip(vn / np.maximum(np.linalg.norm(vn, axis=1, keepdims=True), 1e-6), -1, 1) * 127).astype("i1")
    cq = np.clip(np.round(vc), 0, 255).astype("u1")
    iq = idx.astype("<u2")
    b = lambda a: base64.b64encode(a.tobytes()).decode()
    return {"n": int(len(vp)), "t": int(len(idx) // 3), "p": b(pq), "m": b(nq), "c": b(cq), "i": b(iq)}

def wheel_part(mi, node, s):
    P, N, UV, I = mesh_data(mi)
    m = node_matrix(node)
    sc = np.linalg.norm(m[:3, :3], axis=0)
    R = m[:3, :3] / sc
    yaw = math.atan2(R[0, 2], R[0, 0])       # steering in the model; snap it to 0 / 180 degrees
    yaw = round(yaw / math.pi) * math.pi
    c, sn = math.cos(yaw), math.sin(yaw)
    Ry = np.array([[c, 0, sn], [0, 1, 0], [-sn, 0, c]])
    L = (P * sc) @ Ry.T
    Ln = N @ Ry.T
    centre = m[:3, 3]
    tricol = sample(UV[I].mean(1))
    part = build_part(L, Ln, I, tricol, s)
    cg = to_game(centre[None, :], s)[0]
    r = (L[:, 1].max() - L[:, 1].min()) / 2 * s
    return part, [round(float(x), 4) for x in cg], round(float(r), 4)

CARS = [
    # id, body node, scale, outline mesh, paint tint (brightest palette colour is the base)
    {"id": "ember", "body": 5, "main": 1, "lights": 2, "outline": None, "s": 0.0100},
    {"id": "mamba", "body": 16, "main": 7, "lights": 9, "outline": 8, "s": 0.0100},
    {"id": "solstice", "body": 28, "main": 14, "lights": 15, "outline": None, "s": 0.0108},
]

res = {}
for car in CARS:
    s = car["s"]
    node = J["nodes"][car["body"]]
    P, N, UV, I = mesh_data(car["main"])
    cuv = UV[I].mean(1)
    # the 12 triangles of the nose emblem are mapped to the manufacturer-badge part of the texture: leave them out
    badge = (cuv[:, 0] < 0.64) & (cuv[:, 1] < 0.64)
    I = I[~badge]
    tricol = sample(UV[I].mean(1))
    pmask = np.array([is_paint(c) for c in tricol])
    # the body colour is the most common saturated palette colour; keep only its hue family as paint
    cnt = Counter(tuple(c) for c in tricol[pmask])
    dom = colorsys.rgb_to_hsv(*(np.array(cnt.most_common(1)[0][0]) / 255.0))[0]
    def fam(c):
        h = colorsys.rgb_to_hsv(*(np.array(c) / 255.0))[0]
        dh = abs(h - dom)
        return min(dh, 1 - dh) < 0.07
    pmask = np.array([bool(m) and fam(c) for m, c in zip(pmask, tricol)])
    pcols = tricol[pmask]
    lp = luma(pcols)
    base = pcols[np.argmin(abs(lp - np.percentile(lp, 85)))]   # robust against a few stray bright texels
    bl = luma(base)
    shade = lambda c: np.clip(luma(c) / bl, 0.0, 1.0) * 0.98 + 0.02
    paint = build_part(P, N, I[pmask], tricol[pmask], s, shade=shade)
    trim = build_part(P, N, I[~pmask], tricol[~pmask], s)
    LP, LN, LUV, LI = mesh_data(car["lights"])
    lc = sample(LUV[LI].mean(1))
    white = lc.min(1) > 128
    head = build_part(LP, LN, LI[white], lc[white], s)
    tail = build_part(LP, LN, LI[~white], lc[~white], s)
    allp = to_game(P, s)
    entry = {
        "L": round(float((P[:, 2].max() - P[:, 2].min()) * s), 3),
        "W": round(float((P[:, 0].max() - P[:, 0].min()) * s), 3),
        "H": round(float(P[:, 1].max() * s), 3),
        "paint": "#%02x%02x%02x" % tuple(int(x) for x in base),
        "parts": {"paint": paint, "trim": trim, "head": head, "tail": tail},
        "wheels": [],
    }
    if car["outline"] is not None:
        OP, ON, OUV, OI = mesh_data(car["outline"])
        entry["parts"]["outline"] = build_part(OP, ON, OI, np.zeros((len(OI), 3)), s)
    # wheels: children of the root node named Front/Rear Left/Right with the same suffix as the body
    suffix = node["name"][len("Body"):]
    for nid in node["children"]:
        nn = J["nodes"][nid]
        nm = nn["name"]
        if "Wheel" not in nm:
            continue
        child = J["nodes"][nn["children"][0]]
        part, centre, r = wheel_part(child["mesh"], nn, s)
        entry["wheels"].append({"name": nm.replace(suffix, ""), "c": centre, "r": r, "g": part})
    entry["wheels"].sort(key=lambda w: w["name"])
    entry["wr"] = round(float(np.mean([w["r"] for w in entry["wheels"]])), 3)
    res[car["id"]] = entry
    print(car["id"], "L", entry["L"], "W", entry["W"], "H", entry["H"], "wr", entry["wr"], "paint", entry["paint"],
          {k: v["t"] for k, v in entry["parts"].items()}, "wheels", len(entry["wheels"]))

js = json.dumps(res, separators=(",", ":"))
out.write_text(
    "<script>\n/* Generated by tools/glb-to-cars.py.\n"
    "   \"(FREE) Racing Car in 3 styles\" (https://skfb.ly/oLXFS) by Mena is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).\n"
    "   Geometry only: palette colours are baked into vertex colours, no textures are shipped. */\n"
    "const GLBCARS=" + js + ";\n</script>\n", encoding="utf-8")
print("wrote", out, f"{out.stat().st_size:,} bytes")
