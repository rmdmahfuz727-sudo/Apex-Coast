// Renders branding/*.svg to PNG with Playwright (Chromium).
//   node tools/render-brand.js [outDir]
// Needs `playwright` to be resolvable (npm i playwright, or run where it is preinstalled).
const { chromium } = require('playwright');
const fs = require('fs'), path = require('path');
const root = path.resolve(__dirname, '..');
const out = path.resolve(process.argv[2] || path.join(root, 'branding'));
const srcDir = path.resolve(process.env.BRAND_SRC || path.join(root, 'branding'));
fs.mkdirSync(out, { recursive: true });
const JOBS = [
  // [svg, png, width, height, background]
  ['apex-coast-mark.svg', 'apex-coast-mark-1024.png', 1024, 1024, null],
  ['apex-coast-icon-square.svg', 'play-icon-512.png', 512, 512, '#140A24'],
  ['apex-coast-wordmark.svg', 'apex-coast-wordmark.png', 1200, null, null],
  ['apex-coast-logo-horizontal.svg', 'apex-coast-logo-horizontal.png', 1600, null, null],
  ['apex-coast-logo-stacked.svg', 'apex-coast-logo-stacked.png', 1200, null, null],
];
(async () => {
  const b = await chromium.launch();
  for (const [svg, png, w, h, bg] of JOBS) {
    const src = fs.readFileSync(path.join(srcDir, svg), 'utf8');
    const m = src.match(/viewBox="([-\d. ]+)"/)[1].split(/\s+/).map(Number);
    const hh = h || Math.round(w * m[3] / m[2]);
    const page = await b.newPage({ viewport: { width: w, height: hh } });
    await page.setContent(`<body style="margin:0;background:${bg || 'transparent'}"><div style="width:${w}px;height:${hh}px">${src.replace(/width="[^"]+"\s+height="[^"]+"/, `width="${w}" height="${hh}"`)}</div></body>`);
    await page.screenshot({ path: path.join(out, png), omitBackground: !bg });
    await page.close();
    console.log('wrote', path.relative(root, path.join(out, png)));
  }
  await b.close();
})();
