#!/usr/bin/env python3
"""Generate the Apex Coast logo family from one set of shapes.

Outputs
  branding/*.svg                      mark, horizontal lockup, stacked lockup, wordmark (text converted to outlines)
  android/app/src/main/res/...        adaptive launcher icon (background, foreground, monochrome vector drawables)
  game/src/01-ui.html                 <symbol id="logo-mark|logo-word"> inside the existing SVG sprite
PNG exports are made by tools/render-brand.js (Playwright), which reads the SVGs written here.

The wordmark is set in Inter Display Black Italic (SIL Open Font License) and shipped as plain
outlines, so nothing needs the font at run time.
"""
import math, os, pathlib, re
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen

root = pathlib.Path(__file__).resolve().parent.parent
CONCEPT = os.environ.get("LOGO", "D").upper()          # D = coastal sunset scene (default), A = sunset A, B = roundel, C = chevrons
EXPLORE = os.environ.get("LOGO_OUT")                    # when set: write brand files only there (no Android / UI changes)
BR = pathlib.Path(EXPLORE) if EXPLORE else root / "branding"
RES = root / "android" / "app" / "src" / "main" / "res"
BR.mkdir(exist_ok=True)

# ---- palette -------------------------------------------------------------------------
INK = "#140A24"
VIOLET = "#3A1670"
CYAN = "#3BE8FF"
PINK = "#FF4FA3"
AMBER = "#FFC247"
SUN_TOP = "#FFD36B"
SUN_BOT = "#FF4F8B"

# ---- mark geometry (108 x 108 grid, art kept inside the 66 dp adaptive-icon safe zone) ----
SUNSET = [(0, "#FFFFFF"), (0.42, "#FFE9B0"), (0.62, SUN_TOP), (0.82, "#FF8A5C"), (1, SUN_BOT)]

def lerp(a, b, t):
    return a + (b - a) * t

def sun_pieces(cx, cy, r, cuts):
    """Half sun sitting on y=cy, sliced by horizontal cut bands [(y0, y1), ...] (synthwave stripes)."""
    ys = [cy - r] + [v for c in cuts for v in c] + [cy]
    pieces = []
    def x_at(y):
        return math.sqrt(max(r * r - (y - cy) ** 2, 0))
    # pairs of (top, bottom) y for each visible slice
    edges = [cy - r]
    slices = []
    cur = cy - r
    for (a, b) in cuts:
        slices.append((cur, a))
        cur = b
    slices.append((cur, cy))
    for (a, b) in slices:
        xa, xb = x_at(a), x_at(b)
        if a == cy - r:
            # cap: from the left chord point clockwise over the top to the right chord point
            d = f"M{cx - xb:.2f} {b:.2f}A{r} {r} 0 0 1 {cx + xb:.2f} {b:.2f}Z"
        else:
            d = (f"M{cx - xa:.2f} {a:.2f}L{cx + xa:.2f} {a:.2f}"
                 f"A{r} {r} 0 0 1 {cx + xb:.2f} {b:.2f}L{cx - xb:.2f} {b:.2f}"
                 f"A{r} {r} 0 0 1 {cx - xa:.2f} {a:.2f}Z")
        pieces.append(d)
    return pieces


def poly(pts):
    return "M" + "L".join(f"{x:.2f} {y:.2f}" for x, y in pts) + "Z"

SK = 0.15                                                  # italic lean (dx per dy)

def mark_A():
    """Bold italic A. Lower half of both legs is sliced by sunset stripes."""
    G = dict(sun=dict(x1=54, y1=27, x2=54, y2=83, stops=SUNSET))
    k = 22 / 56                                           # leg slope (dx per dy)
    def outer_l(y): return 46 - (y - 27) * k
    def outer_r(y): return 62 + (y - 27) * k
    def inner_l(y): return 39 + (83 - y) * k
    def inner_r(y): return 69 - (83 - y) * k
    yb = 71.0
    sk = lambda pts: [(x + (83 - y) * SK - 4.2, y) for x, y in pts]
    top = poly(sk([(46, 27), (62, 27), (outer_r(yb), yb), (inner_r(yb), yb), (inner_l(yb), yb), (outer_l(yb), yb)]))
    # counter (hole) above the crossbar, drawn with an even-odd subpath
    hy0, hy1 = 46.5, 60.0
    hw = (hy1 - hy0) * k
    hole = poly(sk([(54, hy0), (54 + hw, hy1), (54 - hw, hy1)]))
    shapes = [dict(d=top + hole, fill="grad:sun", rule="evenodd")]
    for (y0, y1) in [(yb, 74.2), (75.6, 78.6), (80.4, 83)]:
        shapes.append(dict(d=poly(sk([(outer_l(y0), y0), (inner_l(y0), y0), (inner_l(y1), y1), (outer_l(y1), y1)])), fill="grad:sun"))
        shapes.append(dict(d=poly(sk([(inner_r(y0), y0), (outer_r(y0), y0), (outer_r(y1), y1), (inner_r(y1), y1)])), fill="grad:sun"))
    return shapes, G

def mark_B():
    """Roundel: setting sun over a road that runs to the horizon."""
    G = dict(sun=dict(x1=54, y1=36, x2=54, y2=56, stops=[(0, "#FFE9B0"), (0.45, SUN_TOP), (1, SUN_BOT)]),
             road=dict(x1=54, y1=56, x2=54, y2=80, stops=[(0, "#9B5CFF"), (1, "#3A1670")]),
             ring=dict(x1=20, y1=20, x2=88, y2=88, stops=[(0, "#FFFFFF"), (1, CYAN)]),
             dash=dict(x1=54, y1=60, x2=54, y2=78, stops=[(0, PINK), (1, AMBER)]))
    s = []
    cx, cy, r = 54, 54, 34.5
    ring = (f"M{cx - r} {cy}A{r} {r} 0 1 0 {cx + r} {cy}A{r} {r} 0 1 0 {cx - r} {cy}Z"
            f"M{cx - r + 4} {cy}A{r - 4} {r - 4} 0 1 1 {cx + r - 4} {cy}A{r - 4} {r - 4} 0 1 1 {cx - r + 4} {cy}Z")
    s.append(dict(d=ring, fill="grad:ring", rule="evenodd"))
    for d in sun_pieces(54, 55.5, 16, [(44.0, 45.6), (49.0, 51.2)]):
        s.append(dict(d=d, fill="grad:sun"))
    s.append(dict(d=poly([(51.2, 57.5), (56.8, 57.5), (73.5, 79), (34.5, 79)]), fill="grad:road"))
    s.append(dict(d=poly([(53.1, 60), (54.9, 60), (55.4, 63.5), (52.6, 63.5)]), fill="grad:dash"))
    s.append(dict(d=poly([(52.4, 66.5), (55.6, 66.5), (56.5, 71.5), (51.5, 71.5)]), fill="grad:dash"))
    s.append(dict(d=poly([(51.4, 75), (56.6, 75), (57.9, 79), (50.1, 79)]), fill="grad:dash"))
    return s, G

def mark_C():
    """Two stacked chevrons: apex above, sunset below."""
    G = dict(top=dict(x1=54, y1=26, x2=54, y2=42, stops=[(0, "#FFFFFF"), (1, "#CFF8FF")]),
             low=dict(x1=24, y1=0, x2=84, y2=0, stops=[(0, AMBER), (0.5, "#FF8A5C"), (1, PINK)]),
             dot=dict(x1=54, y1=0, x2=54, y2=1, stops=[(0, CYAN), (1, CYAN)]))
    def chev(y, th, fill):
        return dict(d=poly([(54, y), (86, y + 36), (86, y + 36 + th), (54, y + th), (22, y + 36 + th), (22, y + 36)]), fill=fill)
    return [chev(24, 14, "grad:top"), chev(46, 14, "grad:low"), chev(68, 8, "grad:low")], G

def bez(p0, p1, p2, t):
    u = 1 - t
    return (u * u * p0[0] + 2 * u * t * p1[0] + t * t * p2[0], u * u * p0[1] + 2 * u * t * p1[1] + t * t * p2[1])

def blade(base, ang, ln, droop, wmax):
    """One palm frond: a tapered, arched blade from the crown."""
    a = math.radians(ang)
    d = (math.cos(a), -math.sin(a))
    tip = (base[0] + d[0] * ln, base[1] + d[1] * ln + droop)
    ctl = (base[0] + d[0] * ln * 0.5, base[1] + d[1] * ln * 0.5 - ln * 0.2)
    L, R = [], []
    n = 10
    for i in range(n + 1):
        s = i / n
        x, y = bez(base, ctl, tip, s)
        x2, y2 = bez(base, ctl, tip, min(1, s + 0.02))
        x1, y1 = bez(base, ctl, tip, max(0, s - 0.02))
        tx, ty = x2 - x1, y2 - y1
        m = math.hypot(tx, ty) or 1
        nx, ny = -ty / m, tx / m
        w = wmax * (math.sin(math.pi * min(1, s * 0.92 + 0.04)) ** 0.8) * (1 - 0.25 * s)
        L.append((x + nx * w, y + ny * w))
        R.append((x - nx * w, y - ny * w))
    return poly(L + R[::-1])

def mark_D():
    """Coastal sunset: pale sun on the horizon, a road sweeping out to it, a palm. Original artwork."""
    H = 66.0
    G = dict(
        sky=dict(x1=54, y1=0, x2=54, y2=H, stops=[(0, "#D9368F"), (0.38, "#F2557A"), (0.66, "#FF8F5A"), (0.86, "#FFC46A"), (1, "#FFE6A0")]),
        skyglow=dict(kind="radial", cx=56, cy=H, r=46, stops=[(0, "#FFF4C8CC"), (0.5, "#FFE9A055"), (1, "#FFE9A000")]),
        sun=dict(x1=56, y1=H - 19, x2=56, y2=H, stops=[(0, "#FFFDF0"), (1, "#FFEBB0")]),
        ground=dict(x1=54, y1=H, x2=54, y2=110, stops=[(0, "#6A2468"), (0.5, "#41174F"), (1, "#25103D")]),
        road=dict(x1=54, y1=H, x2=54, y2=110, stops=[(0, "#B05A8E"), (0.35, "#8A3F7C"), (1, "#5A2866")]),
    )
    s = []
    s.append(dict(d=f"M37 {H}A19 19 0 0 1 75 {H}Z", fill="grad:sun"))
    s.append(dict(d=f"M-10 {H}Q8 57.5 26 61.5T52 {H}Z", fill="#9A3A78", nomono=True))      # far headland
    s.append(dict(d=f"M70 {H}Q86 59.5 112 {H}Z", fill="#9A3A78", nomono=True))
    s.append(dict(d=f"M-30 {H}H140V140H-30Z", fill="grad:ground", nomono=True))
    rd = f"M-4 112Q32 94 52 {H + 0.5}L59.5 {H + 0.5}Q63 88 80 112Z"
    s.append(dict(d=rd, fill="grad:road"))
    # white edge lines
    s.append(dict(d=f"M-4 112Q32 94 52 {H + 0.5}", fill=None, stroke="#FFF1DC", sw=1.1, cap="butt", join="round", nomono=True))
    s.append(dict(d=f"M59.5 {H + 0.5}Q63 88 80 112", fill=None, stroke="#FFF1DC", sw=1.1, cap="butt", join="round", nomono=True))
    # yellow centre dashes along the road's mid-line, tapering toward the horizon
    mp0, mp1, mp2 = (38.0, 112.0), (47.5, 91.0), (55.75, H + 0.5)
    for (a, b) in [(0.04, 0.2), (0.3, 0.43), (0.53, 0.63), (0.72, 0.8), (0.87, 0.93)]:
        pts = []
        for tt in (a, b):
            x, y = bez(mp0, mp1, mp2, tt)
            x2, y2 = bez(mp0, mp1, mp2, min(1, tt + 0.01))
            x1, y1 = bez(mp0, mp1, mp2, max(0, tt - 0.01))
            tx, ty = x2 - x1, y2 - y1
            m = math.hypot(tx, ty) or 1
            w = 0.35 + 1.5 * (1 - tt) ** 1.6
            pts.append(((x - ty / m * w, y + tx / m * w), (x + ty / m * w, y - tx / m * w)))
        (l0, r0), (l1, r1) = pts
        s.append(dict(d=poly([l0, r0, r1, l1]), fill="#FFD23F", nomono=True))
    # palm: curved trunk + fronds
    cr = (80.0, 41.0)
    tl, tr = [], []
    for i in range(9):
        u = i / 8
        x, y = bez((83.5, 70), (79.5, 56), cr, u)
        w = 1.35 - 0.7 * u
        tl.append((x - w, y)); tr.append((x + w, y))
    s.append(dict(d=poly(tl + tr[::-1]), fill="#331248"))
    for ang, ln, dr, w in [(160, 15, 10, 2.3), (194, 16, 11, 2.4), (228, 13, 7, 2.2), (312, 13, 7, 2.2), (346, 16, 11, 2.4), (20, 15, 10, 2.3), (100, 9, 1, 1.8), (75, 9, 1, 1.8)]:
        s.append(dict(d=blade(cr, ang, ln, dr, w), fill="#331248"))
    return s, G

GRADS = {}
def mark_shapes():
    s, g = {"A": mark_A, "B": mark_B, "C": mark_C, "D": mark_D}[CONCEPT]()
    GRADS.clear(); GRADS.update(g); ALLG.update(g)
    return s

BGN = ("sky", "skyglow") if CONCEPT == "D" else ("bg", "glow")

def background_shapes():
    return [
        dict(d="M0 0h108v108H0z", fill="grad:" + BGN[0]),
        dict(d="M0 0h108v108H0z", fill="grad:" + BGN[1]),
    ]

BGGRADS = {
    "bg": dict(x1=20, y1=0, x2=88, y2=108, stops=[(0, "#2B1066"), (0.5, "#190B3A"), (1, "#0C0618")]),
    "glow": dict(kind="radial", cx=54, cy=70, r=52, stops=[(0, "#FF4FA340"), (0.6, "#FF4FA312"), (1, "#FF4FA300")]),
}
ALLG = {**BGGRADS}
mark_shapes()


# ---- SVG writers ----------------------------------------------------------------------
def hex_to_svg(c):
    """#RRGGBBAA -> (#RRGGBB, opacity)."""
    if len(c) == 9:
        return c[:7], int(c[7:9], 16) / 255
    return c, 1.0

def svg_defs(prefix, names):
    out = []
    for n in names:
        g = ALLG[n]
        gid = f"{prefix}{n}"
        if g.get("kind") == "radial":
            out.append(f'<radialGradient id="{gid}" gradientUnits="userSpaceOnUse" cx="{g["cx"]}" cy="{g["cy"]}" r="{g["r"]}">')
        else:
            out.append(f'<linearGradient id="{gid}" gradientUnits="userSpaceOnUse" x1="{g["x1"]}" y1="{g["y1"]}" x2="{g["x2"]}" y2="{g["y2"]}">')
        for off, col in g["stops"]:
            c, o = hex_to_svg(col)
            out.append(f'<stop offset="{off}" stop-color="{c}"' + (f' stop-opacity="{o:.2f}"' if o < 1 else "") + "/>")
        out.append("</radialGradient>" if g.get("kind") == "radial" else "</linearGradient>")
    return "".join(out)

def svg_shape(sh, prefix, mono=None):
    def paint(v):
        if v is None:
            return "none"
        if mono:
            return mono
        return f"url(#{prefix}{v[5:]})" if v.startswith("grad:") else v
    a = f'<path d="{sh["d"]}" fill="{paint(sh.get("fill"))}"' + (' fill-rule="evenodd"' if sh.get("rule") else "")
    if sh.get("stroke"):
        a += f' stroke="{paint(sh["stroke"])}" stroke-width="{sh["sw"]}" stroke-linecap="{sh["cap"]}" stroke-linejoin="{sh["join"]}"'
    return a + "/>"

def mark_svg_inner(prefix="m"):
    """Art only (108 grid), transparent."""
    names = [g for g in GRADS if g not in BGN]
    return "<defs>" + svg_defs(prefix, names) + "</defs>" + "".join(svg_shape(s, prefix) for s in mark_shapes())

def squircle_path(size, r):
    # superellipse-ish rounded square, drawn with cubic corners
    k = r * 0.5523
    s = size
    return (f"M{r} 0H{s - r}C{s - r + k} 0 {s} {r - k} {s} {r}V{s - r}C{s} {s - r + k} {s - r + k} {s} {s - r} {s}"
            f"H{r}C{r - k} {s} 0 {s - r + k} 0 {s - r}V{r}C0 {r - k} {r - k} 0 {r} 0Z")

def mark_badge_svg(size=512, prefix="b", full_bleed=False, art_scale=1.24):
    """Icon on its gradient tile. Full-bleed square for stores, rounded for brand use."""
    k = size / 108
    body = "<defs>" + svg_defs(prefix, [n for n in BGN] + [g for g in GRADS if g not in BGN]) + "</defs>"
    clip = ""
    if not full_bleed:
        body += f'<clipPath id="{prefix}clip"><path d="{squircle_path(108, 25)}"/></clipPath>'
        clip = f' clip-path="url(#{prefix}clip)"'
    bg = "".join(svg_shape(s, prefix) for s in background_shapes())
    art = "".join(svg_shape(s, prefix) for s in mark_shapes())
    t = f'translate({54 - 54 * art_scale:.3f} {54 - 54 * art_scale + 1.5:.3f}) scale({art_scale})'
    inner = f'<g{clip}>{bg}<g transform="{t}">{art}</g></g>'
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 108 108">{body}{inner}</svg>'

ASC = (1.0, 1.06) if CONCEPT == "D" else (1.24, 1.3)

# ---- wordmark outlines ------------------------------------------------------------------
FD = "/usr/share/fonts/opentype/inter/InterDisplay-"
FONTS = {}
for _k, _f in (("black", "BlackItalic"), ("semi", "ExtraBoldItalic")):
    _t = TTFont(FD + _f + ".otf")
    FONTS[_k] = (_t.getGlyphSet(), _t.getBestCmap(), _t["head"].unitsPerEm, _t["OS/2"].sCapHeight)

# manual pair kerning (font units) for the few pairs that look loose in this lockup
KERN = {("A", "P"): -10, ("P", "E"): 0, ("E", "X"): -8, ("C", "O"): 0, ("O", "A"): -30, ("A", "S"): -10, ("S", "T"): -8}

def text_outline(text, size, track=0.0, font="black"):
    """Return (path_d, width, cap_height) with the baseline at y = 0 and the glyphs growing up (negative y)."""
    GS, CMAP, UPM, CAP = FONTS[font]
    sc = size / UPM
    x = 0.0
    d = []
    for i, ch in enumerate(text):
        gn = CMAP[ord(ch)]
        pen = SVGPathPen(GS)
        tp = TransformPen(pen, (sc, 0, 0, -sc, x, 0))
        GS[gn].draw(tp)
        d.append(pen.getCommands())
        x += GS[gn].width * sc + track * size
        if i + 1 < len(text) and font == "black":
            x += KERN.get((ch, text[i + 1]), 0) * sc
    return " ".join(d), x - track * size, CAP * sc

WG = lambda p, x1, x2: (f'<linearGradient id="{p}g" gradientUnits="userSpaceOnUse" x1="{x1:.1f}" y1="0" x2="{x2:.1f}" y2="0">'
                        f'<stop offset="0" stop-color="{AMBER}"/><stop offset="0.55" stop-color="#FF8A5C"/><stop offset="1" stop-color="{PINK}"/></linearGradient>')

def word_stack(prefix="w"):
    """APEX in heavy italic over a wide-spaced COAST in a lighter weight, both the same width, COAST in the sunset gradient."""
    d1, w1, c1 = text_outline("APEX", 100, 0.0)
    d2, w2, c2 = text_outline("COAST", 100, 0.34, "semi")
    k = w1 / w2
    gap = c1 * 0.2
    h2 = c2 * k
    width = w1 + 6
    height = c1 + gap + h2
    body = (f'<defs>{WG(prefix, 0, width)}</defs>'
            f'<path d="{d1}" transform="translate(0 {c1:.2f})" fill="#FFFFFF"/>'
            f'<path d="{d2}" transform="translate(0 {c1 + gap + h2:.2f}) scale({k:.5f})" fill="url(#{prefix}g)"/>')
    return body, width, height

def word_line(prefix="wl"):
    """APEX COAST on one line: heavy APEX in white, lighter wide-spaced COAST in the gradient."""
    d1, w1, c1 = text_outline("APEX", 100, 0.0)
    d2, w2, c2 = text_outline("COAST", 100, 0.16, "semi")
    gap = 100 * 0.3
    width = w1 + gap + w2 + 6
    body = (f'<defs>{WG(prefix, 0, w2)}</defs>'
            f'<path d="{d1}" transform="translate(0 {c1:.2f})" fill="#FFFFFF"/>'
            f'<path d="{d2}" transform="translate({w1 + gap:.2f} {c1:.2f})" fill="url(#{prefix}g)"/>')
    return body, width, c1

def write(path, text):
    path.write_text(text, encoding="utf-8")
    print("wrote", path, f"{len(text):,} bytes")

# ---- 1. brand SVGs ----------------------------------------------------------------------
write(BR / "apex-coast-mark.svg", mark_badge_svg(512, "a", art_scale=ASC[0]))
write(BR / "apex-coast-icon-square.svg", mark_badge_svg(512, "b", full_bleed=True, art_scale=ASC[1]))

wb, ww, wh = word_stack("s")
write(BR / "apex-coast-wordmark.svg",
      f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="-2 -2 {ww + 4:.1f} {wh + 4:.1f}" width="{ww * 4:.0f}" height="{wh * 4:.0f}">{wb}</svg>')

# horizontal lockup: badge + stacked wordmark
H = 168
bs = H / 108
sw = H * 0.86                       # wordmark height
wsc = sw / wh
gap = 34
total_w = H + gap + ww * wsc
lock = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {total_w:.1f} {H}" width="{total_w * 2:.0f}" height="{H * 2}">'
        f'<g transform="scale({bs:.4f})">{mark_badge_svg(108, "h").split(">", 1)[1].rsplit("</svg>", 1)[0]}</g>'
        f'<g transform="translate({H + gap} {(H - sw) / 2:.1f}) scale({wsc:.4f})">{word_stack("hw")[0]}</g></svg>')
write(BR / "apex-coast-logo-horizontal.svg", lock)

# stacked lockup: badge over one-line wordmark
lb, lw, lh = word_line("sl")
BH = 220
tw = 640
lsc = tw / lw
total_h = BH + 44 + lh * lsc
stack = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {tw} {total_h:.1f}" width="{tw}" height="{total_h:.0f}">'
         f'<g transform="translate({(tw - BH) / 2} 0) scale({BH / 108:.4f})">{mark_badge_svg(108, "t").split(">", 1)[1].rsplit("</svg>", 1)[0]}</g>'
         f'<g transform="translate(0 {BH + 44:.1f}) scale({lsc:.4f})">{lb}</g></svg>')
write(BR / "apex-coast-logo-stacked.svg", stack)

if EXPLORE:
    raise SystemExit(0)

# ---- 2. Android adaptive icon (background and foreground layers are PNGs made by tools/make-icon.js; the themed icon is this vector) -------------------------------------------------------------
AAPT = 'xmlns:aapt="http://schemas.android.com/aapt"'

def a_color(c):
    # android wants #AARRGGBB
    if len(c) == 9:
        return "#" + c[7:9] + c[1:7]
    return c

def a_grad(name, indent):
    g = ALLG[name]
    i = " " * indent
    if g.get("kind") == "radial":
        head = f'{i}<gradient android:type="radial" android:centerX="{g["cx"]}" android:centerY="{g["cy"]}" android:gradientRadius="{g["r"]}">\n'
    else:
        head = (f'{i}<gradient android:type="linear" android:startX="{g["x1"]}" android:startY="{g["y1"]}" '
                f'android:endX="{g["x2"]}" android:endY="{g["y2"]}">\n')
    items = "".join(f'{i}    <item android:offset="{o}" android:color="{a_color(c)}"/>\n' for o, c in g["stops"])
    return head + items + f"{i}</gradient>\n"

def a_path(sh, mono=None):
    lines = ["    <path\n", f'        android:pathData="{sh["d"]}"']
    attrs = []
    def paint(attr, v):
        if v is None:
            return None
        if mono:
            return (attr, mono)
        if v.startswith("grad:"):
            return (attr, ("grad", v[5:]))
        return (attr, v)
    fills = paint("fillColor", sh.get("fill"))
    strokes = paint("strokeColor", sh.get("stroke"))
    simple = []
    nested = []
    for p in (fills, strokes):
        if p is None:
            continue
        if isinstance(p[1], tuple):
            nested.append(p)
        else:
            simple.append(p)
    out = '    <path\n        android:pathData="' + sh["d"] + '"' + ('\n        android:fillType="evenOdd"' if sh.get("rule") else "")
    for a, v in simple:
        out += f'\n        android:{a}="{v}"'
    if sh.get("stroke"):
        out += (f'\n        android:strokeWidth="{sh["sw"]}"\n        android:strokeLineCap="{sh["cap"]}"'
                f'\n        android:strokeLineJoin="{sh["join"]}"')
    if not nested:
        return out + " />\n"
    out += ">\n"
    for a, (_, n) in nested:
        out += f'        <aapt:attr name="android:{a}">\n' + a_grad(n, 12) + "        </aapt:attr>\n"
    return out + "    </path>\n"

def a_vector(shapes, mono=None, comment=""):
    x = ('<?xml version="1.0" encoding="utf-8"?>\n' + (f"<!-- {comment} -->\n" if comment else "") +
         f'<vector xmlns:android="http://schemas.android.com/apk/res/android" {AAPT}\n'
         '    android:width="108dp"\n    android:height="108dp"\n    android:viewportWidth="108"\n    android:viewportHeight="108">\n')
    x += "".join(a_path(s, mono) for s in shapes if not (mono and s.get("nomono")))
    return x + "</vector>\n"

(RES / "drawable").mkdir(parents=True, exist_ok=True)
GEN = "Generated by tools/make-logo.py - edit the script, not this file."
write(RES / "drawable" / "ic_monochrome.xml", a_vector(mark_shapes(), mono="#FF000000", comment=GEN + " Themed (monochrome) icon."))
write(RES / "mipmap-anydpi-v26" / "ic_launcher.xml",
      '<?xml version="1.0" encoding="utf-8"?>\n'
      '<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n'
      '    <background android:drawable="@drawable/ic_bg" />\n'
      '    <foreground android:drawable="@drawable/ic_fg" />\n'
      '    <monochrome android:drawable="@drawable/ic_monochrome" />\n'
      '</adaptive-icon>\n')

# ---- 3. game UI sprite symbols -------------------------------------------------------------
ui = root / "game" / "src" / "01-ui.html"
txt = ui.read_text(encoding="utf-8")
mark_inner = mark_badge_svg(108, "gm").split(">", 1)[1].rsplit("</svg>", 1)[0]
sym = (f'<!--LOGO-->\n    <symbol id="logo-mark" viewBox="0 0 108 108">{mark_inner}</symbol>\n'
       f'    <symbol id="logo-word" viewBox="-2 -2 {ww + 4:.1f} {wh + 4:.1f}">{word_stack("gw")[0]}</symbol>\n    <!--/LOGO-->\n')
if "<!--LOGO-->" in txt:
    txt = re.sub(r"<!--LOGO-->.*?<!--/LOGO-->\n", lambda m: sym, txt, flags=re.S)
else:
    txt = txt.replace('    <symbol id="i-lock"', "    " + sym + '    <symbol id="i-lock"', 1)
ui.write_text(txt, encoding="utf-8")
print("updated sprite in game/src/01-ui.html; wordmark box", round(ww + 4, 1), "x", round(wh + 4, 1))
