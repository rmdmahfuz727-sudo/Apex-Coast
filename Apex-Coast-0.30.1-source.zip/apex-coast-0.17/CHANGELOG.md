# Changelog

## 0.30.1

- **Rain, road reflections:** the wet road no longer acts like a mirror. It is now dark damp asphalt with a soft, weaker sky reflection, and the sun glitter path and sun highlight are switched off under overcast, which removes the large white glare down the road. Lamp reflections are narrower and fainter, and the bloom is dialled back in rain and fog.
- **Puddles:** rebuilt. They have irregular, soft-edged outlines (no hard rim), a darker water tone, a view-angle-dependent sky reflection, a faint lamp reflection and raindrop rings that expand and fade. There are more of them and most lie in the traffic lanes, so you drive through them often.
- **Water splashes:** each tyre that hits a puddle throws a crown of droplets, a sideways bow wave of spray and drifting mist, scaled by speed, then a rooster tail behind. The rear-tyre spray on wet roads is thicker, and rain streaks are longer, brighter and more numerous, with more rain impacts on the road.
- **Fog:** fixed the white glare and flat grey wall. Fog now closes in gradually (about 12 m to 210 m), the car stays clear, the sky and road fade into the haze, and the bloom no longer blows the horizon out. Fog also dulls the sky a little more.
- Version 0.30.1 (versionCode 38).

## 0.30.0

- **Suspension:** the car body now sits on springs. It dips, rebounds and settles when you accelerate, brake, change gear, change lane or hit a road joint, and each wheel moves up and down independently under the body, so you see the suspension compress and extend. Cosmetic only; physics, handling and scoring are unchanged.
- **Acceleration and braking:** the nose lifts and the rear squats on a launch and under nitro; the nose dives under hard braking. Gear changes give a small jolt.
- **Body lean:** the car leans into corners and slides, and the roll overshoots and settles like a real chassis.
- **Wheels:** visible rotation that follows speed, with a stroboscopic slow-down at high speed so the spokes stay readable. Rear wheels spin up on a launch and in a burnout, over-rotate in a drift and lock up under hard braking. Front wheels steer with a little Ackermann angle.
- **Burnout:** hold Brake and Drift (or Gas) while stopped. The rear wheels spin, the engine screams, the car shakes and the tyres smoke.
- **Steering wheel and driver:** seven cars (Vesper, Pebble, Kestrel, Bruiser, Mirage, Dune, Halcyon) have a modelled cockpit with a steering wheel that turns with your input, a driver whose hands follow the wheel and whose head turns into corners, a dash and seats. You see them through the tinted glass. Ember, Mamba and Solstice are closed bodies, so they keep the steering front wheels and body movement only.
- **New camera views:** a camera button next to Restart (or press C) cycles Chase, Hood and Cockpit views. The choice is saved.
- **Moving rear wing:** Kestrel and Halcyon have a real active wing. It is stowed at low speed, rises above about 105 km/h, tilts into an air brake under braking and flattens on nitro.
- **Damage and scratches:** crashes, lost lives and wall scrapes leave scratch marks along the sides; front and rear hits dent the hood or boot and crack the windshield; heavy damage makes the car sit slightly crooked and smoke from the engine bay. Damage resets at every new run. Cosmetic only.
- **HUD customisation:** Settings, HUD, Customize opens a live layout screen. Drag any HUD element (speed, score, objective, combo, nitro bar, distance, buttons) and either touch pad to a new spot; show or hide each part of the HUD; set the HUD size and opacity and the touch controls' size and opacity separately; remove the black bars; swap the control sides for left-handed play; switch speed and distance to MPH and miles. Minimal gives a clean HUD in one tap and Reset restores the default. The layout is saved with your other settings and is validated on load. Gameplay and input are unchanged, and the touch pads can be moved and resized but never hidden.
- Version 0.30.0 (versionCode 37).

## 0.29.0

- **Bug fix, cliff and tunnel walls:** the Mountain Cliff Road no longer fills the screen with huge flat rock walls. The cliff is now a terraced, broken rock face with ledges, pines and boulders, set back from the road, so the camera never ends up inside a wall at low speed.
- **Settings:** Road and Location are gone from Settings (Location is still chosen from the menu and Modes). Weather has a new **Auto** option, where the weather changes on its own and each location brings its own conditions. Existing saves keep their current weather choice. Clear, Rain, Storm and Fog still lock the weather.
- **Prop packs:** both attached packs are now part of the game as one shared prop library (62 unique models after 7 exact duplicates were dropped): cones, drums, signs, bollards, barriers, guardrails, mailboxes, crates, benches, streetlights, palms, bushes, boulders, cactus, parasols, chairs, fuel pumps, vending machine, phone booth, fences, hydrants, lanterns and more. They are merged into 50 m roadside chunks, one draw call per chunk per side.
- **Landmark buildings:** gas station, motel, beach restaurant, convenience store, garage, observation tower, pier, beach huts, coastal house and kiosk, built from modular boxes, gables and library props. Each location picks its own set.
- **Engine sounds:** every car has its own engine voice (inline-4, buzzy turbo, electric whine, big-block lope, high-revving screamer, smooth V12, boxer burble, rotary rasp, twin-turbo, screaming high-rev).
- **Turbo whistle and blow-off** for the turbo cars, **backfire pops** on lift-off, **tyre screech**, richer **nitro** launch, sustain and release sounds.
- **Ambience:** ocean swell and gusts on coastal locations, wind that builds with speed, rain bed, all ducked as speed rises.
- **Collisions:** heavier crash (boom, crunch, glass), lighter bumps and scrapes, and passing-car whooshes that pan left and right.
- **Dynamic music:** the soundtrack gets calmer in menus and builds with speed, nitro, combos and pursuits.
- **Controller vibration:** phone haptics (Android native bridge, with a browser fallback) and gamepad rumble for crashes, bumps, nitro, near misses, scrapes, lost lives and busts. Gamepads can also drive the car (stick or d-pad to steer, trigger or A for gas, brake, drift, nitro, Start to pause). New Vibration setting.
- **Graphics settings:** Resolution, Shadows and Reflections each have an Auto setting on top of the Low/Med/High/Ultra tiers, so you can trade detail for speed.
- **Save-data protection:** every save is checksummed and validated, a backup copy is kept, a copy is mirrored on Android, and a damaged save is repaired from the backup instead of being lost. The Settings screen shows the save status and has a Restore backup button. Saves also flush when the app is paused or hidden.
- **Android stability:** render-process crash recovery, memory-pressure handling, WebGL context loss and restore handling, and an error log with automatic recovery to the menu after repeated frame errors.
- **Menus and loading:** menu screens fade and slide in and out, the loading screen is animated, and the garage has an animated backdrop.
- Version 0.29.0 (versionCode 36).

## 0.28.0

- **Traffic types:** taxis (erratic, brake suddenly), SUVs, pickups with a load bed, buses, motorbikes with riders (fast, weave between lanes) and police patrol cars join the sedans, coupes, vans, lorries and GTs. Each has its own speed and behaviour.
- **Smarter traffic:** cars signal and pull out to overtake slower traffic (and speed up while doing it), faster cars come up from behind and pass you if you cruise slowly, cars brake hard at random (brake lights on), and a car that cannot stop in time shunts the one in front. Pile-ups throw sparks, debris and smoke, and are heard and felt from a distance. Traffic density adapts to your speed and combo and to the location.
- **Police pursuit:** speed past a patrol car, or wait for a random event, and units chase you from behind with sirens, flashing lights and a screen-edge glow. Keep your speed up, lose them in traffic (cops that hit civilians are wrecked for a bonus) and escape for credits. Stay glued to a cop's bumper and you are busted.
- **Near-miss scoring** now counts cars that pass you from behind as well.
- **New modes** (unlocked by best score): Time trial (5 km, best time saved), Traffic dodge (3 lives, triple close calls), Endless highway (changes location every 2 km), Drift competition (drifts only, chains, bronze/silver/gold medals with one-time rewards), Checkpoint run (gates add time), Distance challenge (7 targets from 3 to 35 km, credits each), Police chase (rising heat, up to 3 units, takedown bonuses). Coast run, Time attack and Rush hour are unchanged.
- **Daily missions:** three new missions every day (same for everyone), ◆ 800 bonus for finishing all three, streak counter. Reached from the menu. The lifetime missions are unchanged.
- **Seven locations** (menu or Modes: Location): Sunset Beach Highway, Tropical Palm Coast, Mountain Cliff Road (rock walls, falls, a tunnel, a long drop), Coastal Village, Ocean Bridge (steel truss, towers and cables over open water), Desert Beach Highway (dunes, cacti, mesas, a gas station, telephone poles) and Night Coast Highway. Each sets its own time of day, weather, haze and colour grade, and has its own scenery and barriers. All roads are the same four straight lanes; what changes is everything around them. Time of day and weather can still be changed afterwards in Settings.
- Version 0.28.0 (versionCode 35).

## 0.27.0

- **Weather** (Settings, Weather: Clear / Rain / Storm / Fog; Night is still under Time). Changes ease in over a few seconds.
  - Rain: rain streaks that slant with your speed, overcast sky, the sun hidden, thicker haze, a wet glossy road with lamp and sky reflections, rain ripples, puddles on the road, splashes when your tyres hit a puddle (with a splash sound) and a fine spray off your tyres and the traffic ahead. A steady rain sound plays.
  - Storm: heavier rain, dark thick clouds, lightning bolts that flash the whole scene with delayed thunder, stronger wind and bigger waves.
  - Fog: visibility closes to about 140 m with a grey-white horizon; lamps and headlights switch on in daytime murk.
- **Animated palm trees:** trunks bend and fronds flutter in the wind, each palm on its own rhythm. The wind is stronger in storms.
- **Moving clouds:** soft cloud banks drift across the sky and slide past as you drive, plus a faster-moving cloud layer in the sky itself. Cover, colour and darkness follow the weather and the time of day.
- **Ocean waves:** rolling swell that travels toward the beach, whitecaps and foam where the waves break on the sand. Waves grow in rain and storms.
- Quality tiers scale rain, spray and splashes. Puddles and handling are visual only: nothing changes how the car drives.
- Version 0.27.0 (versionCode 34).

## 0.26.0

- **Two-way roads.** The highway now has a double-yellow centre line. Lanes 1-2 (left) carry oncoming traffic with their headlights facing you (they glow at night); lanes 3-4 go your way. Head-on hits crash like any other. Driving in the oncoming lanes doubles your distance score, and oncoming near misses pay double. Settings and the Modes screen have a Road switch (Two-way / One-way) if you prefer the old layout.
- **Village map** (Settings or Modes, Map: Village): meadows, fields, cottages, a barn, a windmill, a church, orchards, hay bales, sheep, wooden lantern poles and a lake. Original low-poly art, renders in fewer draw calls than the coast.
- **3 new cars:** Pebble (hot hatch, grip), Bruiser (muscle car, launch), Dune (rally 4x4). Original models built from the same generator as the starter cars, each with its own lamps, trim, wheels and livery.
- **Effects pass:** tyre smoke from the real rear-wheel positions (light in turns, thick in drifts, burnout when pulling away from a stop, drifts to the lee side with the breeze); skid marks that follow the tyres; ground dust and pebbles in slides; backfire and exhaust pops on lift-off and gear changes (engines that support it) with a pop sound; layered exhaust flames (white core, orange body, blue at the pipe); nitro blue-white core, cyan trails, rear glow, kick on activation and an eased fade-out; a small heat-haze ripple behind the exhausts; road dust at high speed; sand puffs when scraping the wall; sand and salt specks drifting on the breeze. Everything is pooled and scales with the graphics tier (Low about 40% of High).
- Speed lines are now warm white and cyan instead of pink.
- Version 0.26.0 (versionCode 33).

## 0.25.3

- Fixed the crash: the car used to roll a full turn around its wheels and sink under the road. It now tips over and lands back on its wheels, and its body can never go below the road surface.
- Real headlights: spot lights now sit on the car's own lamps (positions are read from each model's headlight geometry, so they work on every car), with a soft light cone and a glow on each lamp. They fade in at dusk and night and fade out when you crash. Low quality has none, Medium one light, High and Ultra two. The old flat glow on the road in front of the car is gone.
- Version 0.25.3 (versionCode 32).

## 0.25.2

- App icon redone in the style of racing-game store icons: a hero shot of Ember with a big APEX COAST title across the top and the coastal-sunset emblem on a cream swoosh in the corner. The launcher icon is now two PNG layers (`drawable-nodpi/ic_bg.png`, `ic_fg.png`) plus the themed monochrome vector; the Play icon (`store/icon-512.png`) and a preview (`branding/apex-coast-icon-1024.png`) come from the same artwork. Rebuild with `node tools/icon-art.js` then `node tools/make-icon.js`.
- The icon shows the Ember car model, so the Mena credit applies to it as well.
- Version 0.25.2 (versionCode 31).

## 0.25.1

- New logo: a coastal sunset emblem (pale sun on the horizon, a road curving out to it, a palm) in the pink-to-gold palette, with a two-weight APEX / COAST wordmark. Used for the launcher icon (adaptive and themed), menu title, loading screen, Play icon, feature graphic and `branding/`. The logo is original artwork; it only takes its mood from the reference image.
- Car credit: Settings now reads "Car models by Mena". The full CC BY 4.0 wording for "(FREE) Racing Car in 3 styles" (https://skfb.ly/oLXFS) is in `THIRD_PARTY_NOTICES.md`, the README and the Play listing text.
- Links in Settings now open in the phone's browser instead of replacing the game page.
- Version 0.25.1 (versionCode 30).

## 0.25.0

- Three new cars from the supplied "Racing Car in 3 styles" model: **Ember** (orange supercar), **Mamba** (green, cel-shaded with a black outline) and **Solstice** (yellow short-wheelbase track special). They sit in the garage between the existing cars, can be repainted, and each has its own nitro flame colour. Credit to Mena (CC BY 4.0) is in Settings and THIRD_PARTY_NOTICES.md.
- New logo: an "A" whose crossbar is the horizon, with a striped sunset and a centre line running to it. New launcher icon (adaptive, plus a monochrome themed icon), menu title, loading screen and brand files in `branding/`.
- Android: compileSdk and targetSdk 36 (required for new Google Play apps), Android Gradle Plugin 8.10.1.
- Version 0.25.0 (versionCode 29).

## 0.24.0

- Hero cars rebuilt toward the concept sheet: carbon-fibre wings, splitters, diffusers and engine louvers (a real weave texture) on Kestrel, Mirage and Halcyon; hexagon-vented engine cover and Y-shaped tail lights on Mirage; a wide magenta-to-cyan synthwave stripe over the hood, roof and deck of Kestrel; coloured wheel lips and rims (purple, blue, orange).
- Bodies are now rounded: narrower roof and nose so they read as teardrop supercars instead of boxes.
- Paint is deeper and richer (deep purple, electric blue, fire orange) with a subtle iridescent edge sheen; the old values washed out to pastel under the sunset light. Kestrel is now #5b2db8 and Halcyon #ee5a14.
- Version 0.24.0 (versionCode 28).

## 0.23.1

- Fixed rocks and plant clusters that could spawn on or overlap the road. A scan of every recycled prop over thousands of metres now finds nothing standing in the driving lanes (street-lamp arms and tall palm crowns still reach over the road high up, by design).
- Version 0.23.1 (versionCode 27).

## 0.23.0

- Premium UI motion: every screen now animates in (top and bottom bars slide, content rises, cards and rows stagger), and a slanted amber wipe sweeps between screens and into a run.
- Press feedback on all buttons (squish and spring back), a slow sheen across the Start and Drive buttons, and credit and best-score counters that count up.
- Results: the score counts up, the stat rows stagger in, and the New record badge stamps in with a glow.
- Garage: stat bars fill from the left and the car name slides in the direction you swipe.
- HUD: combo and objective counters pop when they change, and the nitro bar pulses while boosting.
- Everything uses transform and opacity only, and is switched off by the system "reduce motion" setting.
- Version 0.23.0 (versionCode 26).

## 0.22.0

- Stylised low-poly look inspired by #DRIVE: every prop is flat-shaded (faceted), world lighting is quantised into soft cel bands, and fog is much heavier (purple haze at night, warm haze at sunset) so distant scenery fades out.
- Film grade: crushed blacks, cool shadows and warm highlights, finer film grain, grade keyed to time of day.
- High and Ultra: a proper downscaled bloom (bright-pass, separable blur) for the sun, lamps and neon, and a real soft shadow for the player car. If the frame rate collapses, the game drops these first.
- New #DRIVE-style props: coloured bunting strung across the road, painted casas with balconies and warm lit windows at night, and crate-and-barrel stalls with striped awnings.
- Motion blur: speed-based zoom blur toward the vanishing point that grows with speed and nitro and leaves your car sharp. Settings has a Motion blur On/Off switch (needs Medium or higher).
- Removed the chromatic aberration (colour fringing) effect from nitro and crashes.
- Asphalt now has a sky sheen and a sun or moon glitter path.
- New docs/GRAPHICS_GUIDE.md describing the whole pipeline with code.
- Version 0.22.0 (versionCode 25).

## 0.21.2

- Barrier graffiti: the tags used to straddle the crease where the barrier's lower slope meets the upper slope, so the lettering looked bent and overlapped. Tags now sit entirely on the flat upper face, are drawn at twice the resolution, and are smaller so words no longer crowd each other.
- Camera near plane moved from 0.3 to 0.6 for better depth precision, which reduces flicker on distant surfaces.
- Version 0.21.2 (versionCode 24).

## 0.21.1

- Fixed the big circular rainbow glare and dark blob in the sky: the colour grade overshot on very bright pixels. Colours are now clamped, bloom only picks up true highlights, and the sharpening filter is limited so it cannot ring.
- Daytime sky is a deeper blue with a softer sun glow.
- Version 0.21.1 (versionCode 23).

## 0.21.0

- Fixed palms and plants growing on or over the road: trees now stand clear of the road edge, including their leaning trunks and fronds.
- Graphics quality: higher render resolution on Medium, High and Ultra (the adaptive scaler still protects the frame rate), sharpening filter, light bloom on Medium, full texture filtering on buildings and signs, soft ground shading on every prop, and fuller palm crowns.
- Version 0.21.0 (versionCode 22).

## 0.20.0

- Day and night cycle: a full cycle takes 5 minutes (sunset, dusk, night, dawn, day, golden hour). The sky, fog, ocean, lights and exposure all follow it.
- Night: stars and a crescent moon, lit building windows, brighter street-lamp and beach-bar glow, full-strength neon signs and a headlight beam on the road. Signs dim a little in daylight.
- New Settings row "Time": Auto (cycle), Day, Sunset or Night.
- Version 0.20.0 (versionCode 21).

## 0.19.0

- Concept-sheet assets: sand, stucco, wood-plank and corrugated-metal textures cut from your sheet now cover the ground and the SUNTEE café / gas station (stucco walls, wood shed, metal door and canopy).
- New props: MOTEL pole signs with green L-bracket neon and VACANCY, SUNTEE multicolour neon rooftop sign, Synthwave / Lightning / Fire-boost car liveries with side decals.
- Nitro effects per car: neon magenta-cyan trail (Kestrel), blue-white electric arcs (Mirage), fat orange fire boost (Halcyon), classic blue flame (Vesper).
- Denser roadside: more palms, plants, rocks, beach clutter, near buildings, vending kits, cafes and motel signs. Draw calls about 490 on Medium (was 575 in 0.6.0).
- Version 0.19.0 (versionCode 20).

## 0.18.0

- Roadside detail pass: graffiti jersey barriers replace the guardrails, tall solar street lamps with glowing heads, large foreground palms,
  agave, saguaro and barrel cactus clusters with pink-flower shrubs, neon shop signs (Motel, Arcade, Diner, Surf shop and more) on the buildings,
  a beach bar with string lights, parasols and surfboards on the sand, vending machines, bus shelters and benches.
- Sky: sun spikes around the disc. Road: long tyre skid arcs.
- Version 0.18.0 (versionCode 19).

## 0.17.1

- Removed the duplicate Profile and Modes icons from the main menu top bar and the Profile side tab. Profile opens from the rank plate (top right), Modes from the Modes tab.
- Version 0.17.1 (versionCode 18).

## 0.17.0

- Hub-style main menu: icon row (settings), rank plate with avatar, slanted Modes and Profile tabs, mission card, big Start button.
- New Modes screen with cards: Coast run, Time attack (unlocks at 3,000 best) and Rush hour (unlocks at 8,000 best), plus a Zen switch (no crashes, no score).
- New Driver profile: editable name on a licence card, lifetime stats, six original helmet avatars unlocked by rank.
- Lifetime missions (overtakes and close calls) pay credits; each run has pass goals that pay a bonus.
- In-run HUD redesigned: letterbox bars, large slanted pause, driver plate with score, bottom bar with combo, nitro and distance-versus-record gauges, outlined captions.
- Garage shows the neighbouring cars as a dim lineup on a pedestal, full stat names and a level badge.
- Per-mode records; results screen names the mode and lists mission and goal rewards.
- Version 0.17.0 (versionCode 17).

## 0.16.0

- New interface in a dark charcoal and amber style: letterbox top and bottom bars, slanted plates, heavy italic type.
  Rebuilt the main menu, garage, settings, pause, results, HUD and touch controls.
- Garage: preview any car before buying, stat bars, Cars / Paint / Tune tabs, previous and next buttons, one Select / Buy button.
- Driver rank on the main menu (Rookie to Legend) based on your best score, plus runs and longest drive.
- Short landscape phones (about 360 px tall) and portrait layouts no longer clip.
- Performance: busy-traffic draw calls cut from about 840 to about 420 (merged guardrail, rock and shrub meshes,
  single-material traffic wheels, merged car bodies, hidden brake glow, cached car geometry).
- Player cars get a livery (flank blades, hood and deck ribbons, brake calipers) and every car casts a soft sun shadow.
- Version 0.16.0 (versionCode 16).

## 0.15.0

Coastal visual and interface refresh: ACES tone mapping, warm guardrail reflectors, low-poly rock shelves and dune shrubs,
higher Ultra render resolution.

## 0.11.0 – 0.14.0

Beach-detail clusters (dune grass, pebbles, driftwood), stylised coastal graphics pass, softer car paint and underglow.

## 0.8.0 – 0.10.0

Natural tropical palette replaces the neon look. Merged island silhouettes, coastal resort buildings, recycled rocks and scrub.

## 0.2.0 – 0.6.0

Beta label, touch-target and focus polish, smoother chase camera, sea glints, procedural asphalt and facade textures,
more detailed cars, developer credit with GitHub link in Settings.
