package com.mahfuzrahman.apexcoast;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ComponentCallbacks2;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

/** Hosts the Apex Coast web game in a full-screen WebView. Developed by Mahfuz Rahman. */
public class MainActivity extends Activity {
    private static final String START_URL = "file:///android_asset/index.html";
    private static final String PAUSE_JS =
            "try{if(window.__ac&&__ac.GM&&__ac.GM.state==='play')__ac.pauseGame();}catch(e){}"
                    + "try{if(window.save)save();}catch(e){}";
    private static final String LOWMEM_JS = "try{if(window.apexLowMem)apexLowMem();}catch(e){}";

    private WebView web;
    private long lastBack = 0;
    private OnBackInvokedCallback backCallback;
    private boolean rendererGone = false;

    /** Bridge for the game page: a second copy of the save in app storage, and phone vibration patterns. */
    private class NativeBridge {
        private final SharedPreferences prefs = getSharedPreferences("apexcoast", Context.MODE_PRIVATE);

        @JavascriptInterface
        public void saveData(String data) {
            if (data != null && data.length() < 200000) prefs.edit().putString("save", data).apply();
        }

        @JavascriptInterface
        public String loadData() {
            return prefs.getString("save", "");
        }

        /** csv = on,off,on,off... in milliseconds, like navigator.vibrate. */
        @JavascriptInterface
        public void vibrate(String csv) {
            try {
                String[] parts = csv.split(",");
                if (parts.length == 0 || parts.length > 12) return;
                long[] pattern = new long[parts.length + 1];
                long total = 0;
                for (int i = 0; i < parts.length; i++) {
                    long v = Math.max(0, Math.min(400, Long.parseLong(parts[i].trim())));
                    pattern[i + 1] = v;
                    total += v;
                }
                if (total <= 0 || total > 1500) return;
                Vibrator vib;
                if (Build.VERSION.SDK_INT >= 31) {
                    VibratorManager vm = (VibratorManager) getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
                    vib = vm == null ? null : vm.getDefaultVibrator();
                } else {
                    vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                }
                if (vib != null && vib.hasVibrator()) {
                    vib.vibrate(VibrationEffect.createWaveform(pattern, -1));
                }
            } catch (Exception ignored) { }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        web = new WebView(this);
        web.setBackgroundColor(0xFF140A24);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setLongClickable(false);
        web.setOnLongClickListener(v -> true);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        // Links in Settings (developer profile, car-model credit and licence) open in the phone's browser,
        // so the game page is never replaced. Only the bundled game and its font stylesheet load in the WebView.
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String sc = u.getScheme();
                if ("file".equals(sc)) return false;
                if ("http".equals(sc) || "https".equals(sc)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, u));
                    } catch (ActivityNotFoundException ignored) { }
                }
                return true;
            }

            /** The WebView renderer process was killed (usually low memory): rebuild the activity instead of crashing the app. */
            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                rendererGone = true;
                runOnUiThread(() -> recreate());
                return true;
            }
        });
        web.addJavascriptInterface(new NativeBridge(), "ApexNative");
        web.setWebChromeClient(new WebChromeClient());

        // restoreState returns null when the bundle holds no page (for example after a renderer crash): load the game fresh then.
        if (savedInstanceState == null || web.restoreState(savedInstanceState) == null) {
            web.loadUrl(START_URL);
        }
        hideSystemBars();

        // Apps that target Android 16 (API 36) no longer get onBackPressed(); the predictive-back callback replaces it.
        if (Build.VERSION.SDK_INT >= 33) {
            backCallback = this::handleBack;
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, backCallback);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (web != null && !rendererGone) web.saveState(outState);
    }

    @SuppressWarnings("deprecation")
    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    @Override
    protected void onPause() {
        if (web != null) {
            web.evaluateJavascript(PAUSE_JS, null);
            web.onPause();
        }
        super.onPause();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW && web != null) {
            web.evaluateJavascript(LOWMEM_JS, null);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
        hideSystemBars();
    }

    /** First back press pauses the run, a second one within two seconds exits. */
    private void handleBack() {
        long now = System.currentTimeMillis();
        if (now - lastBack < 2000) {
            finish();
            return;
        }
        lastBack = now;
        if (web != null) web.evaluateJavascript(PAUSE_JS, null);
        Toast.makeText(this, R.string.press_back_again, Toast.LENGTH_SHORT).show();
    }

    /** Android 12 and older still call this; newer versions use the callback above. */
    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (Build.VERSION.SDK_INT >= 33) {
            super.onBackPressed();
        } else {
            handleBack();
        }
    }

    @Override
    protected void onDestroy() {
        if (Build.VERSION.SDK_INT >= 33 && backCallback != null) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backCallback);
        }
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
