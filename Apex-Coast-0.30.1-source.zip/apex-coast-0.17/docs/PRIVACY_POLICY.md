# Privacy Policy for Apex Coast

**Effective date:** 1 November 2026
**Developer:** Mahfuz Rahman
**Contact:** [YOUR CONTACT EMAIL]

Apex Coast ("the game") is an offline racing game for Android. This policy explains what information the game does and does not handle.

## Summary

- The game does not collect, store on a server, sell or share your personal information.
- There are no accounts, no ads, no analytics, no tracking and no in-app purchases.
- Your progress stays on your phone.

## Information stored on your device

The game saves your progress (credits, unlocked cars, paint and upgrades, best scores, settings and the driver name you type in) in the app's local storage on your phone. This information never leaves your device. You can erase it at any time with **Settings > Reset progress**, by clearing the app's storage in Android settings, or by uninstalling the game.

## Network access

The game runs offline. It asks for the Internet permission only so it can load its display font (Montserrat) from Google Fonts when your phone is online. That is an ordinary web request to Google, so Google receives your IP address and device details in the way any website or app request does, as described in the [Google Fonts privacy FAQ](https://developers.google.com/fonts/faq/privacy). If the phone is offline, the game uses a system font instead and everything else works the same.

The game does not send any gameplay or personal data to the developer or to any third party.

## Permissions

| Permission | Why |
|---|---|
| Internet | Load the display font from Google Fonts (optional, the game works without it) |

The game does not ask for your location, contacts, camera, microphone, photos, files or phone identity.

## Children

The game is a casual racing game with cartoon-style graphics. It does not collect personal information from anyone, including children.

## Third-party material

The game uses three.js (MIT licence) for graphics and three car models by Mena ("(FREE) Racing Car in 3 styles", CC BY 4.0, https://skfb.ly/oLXFS). Neither one collects data. See `THIRD_PARTY_NOTICES.md`.

## Changes to this policy

If this policy changes, the new version will be published at the same address with a new effective date.

## Contact

Questions about this policy: [YOUR CONTACT EMAIL]
