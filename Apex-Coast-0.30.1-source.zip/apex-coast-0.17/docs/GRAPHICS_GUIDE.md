# Apex Coast graphics pipeline (Three.js r128, WebGL1/2, mobile first)

Every snippet below is the code that ships in `game/src/`. File names in brackets say where to find it.

## 0. Frame budget and guardrails

| Tier | Render scale | Post | Extras |
|---|---|---|---|
| Low | 0.62 | none | blob shadows |
| Med | min(dpr, 1.1) | grade, sharpen, 4-tap highlight glow | blob shadows |
| High | min(dpr, 1.5) | grade, sharpen, 1/4-res separable bloom | player shadow map, env probe |
| Ultra | min(dpr, 2) | same as High | same as High |

* Adaptive resolution (`adapt()` in `05-game.html`): every 150 frames, if the average frame time is above 1.3x the cap, `dyn` drops by 0.1 (floor 0.55) and the canvas is resized.
* High-tier guardrail: once `dyn <= 0.75`, `HQFX` is set to false. That removes the shadow map and the bloom passes before resolution drops any further. Changing the quality setting turns it back on.
* All render targets are RGBA8 (no float or half-float textures), so they work on every WebGL1 phone.
* Draw calls: about 490 on Med with 12 traffic cars. Props are merged with `bake()` into one mesh per variant.

## 1. Low-poly material pipeline

### 1.1 Faceted geometry
`bake()` [`03-scene.html`] merges parts into one vertex-coloured geometry. Parts are converted to non-indexed and given per-face normals, so every triangle is flat shaded:

```js
g = g.index ? g.toNonIndexed() : g;
if (!p.smooth) g.computeVertexNormals();   // faceted by default
```

Pass `smooth:true` on a part to keep interpolated normals (not used for the world; cars have their own builder).

### 1.2 Matte palette
World props use `MeshLambertMaterial({vertexColors:true})`: no textures and no specular, so shading is colour times light. `bake()` also multiplies vertex colour by a ground gradient (0.74 at the base, 1.0 above 2.6 m) as cheap baked ambient occlusion.

### 1.3 Cel / posterised lighting
`toonify(material)` [`03b-daynight.html`] patches any Lambert or Standard material. It quantises the lit luminance into soft-edged bands, keeps the hue, and keeps a floor so shadows never go black:

```glsl
vec3 toonQ(vec3 c){
  float l = dot(c, vec3(.333));
  float b = l * 4.5;
  float q = (floor(b) + smoothstep(.36, .64, fract(b))) / 4.5;   // soft-edged stair, no aliasing
  return c * (mix(l, q, uToonK) / max(l, .003));                  // uToonK = 0.62 (TOON.k)
}
// injected before #include <tonemapping_fragment>, so fog still fades the bands with distance
```

`TOON.k` is the strength: 0 is smooth, 1 is hard cel. Terrain, road and car paint stay smooth on purpose so the bands read as a style and not as noise.

## 2. Fog and environment depth

Fog colour equals the sky horizon colour, so distant props dissolve into the sky. Near and far distances come from the same time-of-day keyframes as the sky [`GK` in `03b-daynight.html`]:

| Time | near | far |
|---|---|---|
| Sunset | 70 | 950 |
| Dusk | 40 | 700 |
| Night | 22 | 520 (purple haze) |
| Day | 130 | 1250 |

Both the sky and the ocean shader read the same `SKYU.hor` vector, so the horizon never shows a seam. Strips recycle at about 1,300 m, which is far beyond the night fog, so pop-in is hidden.

### Shadows
* **Traffic:** one soft blob quad per car (`shadowGeo` / `shadowMat`, polygon-offset so it never z-fights the road). This costs one draw call per car.
* **Player (High and Ultra):** a real 1024 PCF-soft shadow map from the sun or moon. The shadow camera is a 18 m box around the player, so the texel density is about 1.7 cm. Only the player meshes cast, and only the road receives:

```js
const sc = sunLight.shadow.camera; sc.left=-9; sc.right=9; sc.top=9; sc.bottom=-9; sc.near=120; sc.far=360;
sunLight.shadow.mapSize.set(1024,1024); sunLight.shadow.bias=-.0005; sunLight.shadow.normalBias=.03;
road.receiveShadow = true;   // player.group meshes: castShadow = true, blob hidden
```

## 3. Sky, ocean, asphalt

* **Sky** [`makeSky()`]: a single shader on a sphere with no textures. Its gradient, sun disc, spikes, cloud bands, stars and crescent moon all follow uniforms from `SKYU`, so day, sunset and night come from one shader.
* **Ocean** [`oceanMat`]: a flat plane, with no vertex displacement. Two scrolling noise layers give colour. A glint mask is aligned to the sun's azimuth, and a fresnel term blends toward the horizon colour. Cost is one draw call.
* **Asphalt** [`roadMat.onBeforeCompile`]: PBR plus a grazing-angle sky sheen and a narrow sun or moon glitter path:

```glsl
vec3 Vs = normalize(vViewPosition);
float fr = pow(1. - clamp(dot(normal, Vs), 0., 1.), 4.);
vec3 Rs = reflect(-Vs, normal);
float sp = pow(max(dot(Rs, uSunV), 0.), 70.);
gl_FragColor.rgb += (uSheen * fr * .28 + uSunC * sp * .4) * uSheenK;
```

## 4. Post-processing and grade

Pipeline: scene into a multisampled RGBA8 target, then (High and above) a bright-pass at 1/4 resolution, two separable 5-tap gaussian blurs (twice, at 1.5 px and 3.3 px radius), then a composite pass.

* **Bloom without banding or artifacts:** the bright-pass weights the weakest colour channel (`mix(luma, min(r,g,b), .6)`), so only near-white highlights (sun core, neon, flares) glow. Sunlit sand and road do not. The blur result is added in the final shader, where about 3/255 of film grain breaks up any remaining banding.
* **Never let the grade overshoot:** `col = clamp(col, 0., 1.)` before the S-curve. The curve `c*c*(3-2c)` goes negative above 1.5, which was the cause of the rainbow ring and dark blobs seen in the sky in 0.21.0.
* **Grade** (one shader, uniforms keyed to time of day through `GRADE`):

```glsl
col = mix(vec3(lum), col, uSat);                 // saturation (1.1 day .. 1.24 sunset)
col *= uTint;                                    // warm at sunset, cool at night
col = mix(col, col*col*(3.-2.*col), uCon);       // contrast S-curve (.34 .. .46)
col = max(col - .03, 0.) / .97;                  // crushed blacks
col *= mix(vec3(.93,.95,1.05), vec3(1.05,1.01,.95), smoothstep(.12,.72,luma)); // cool shadows / warm highlights
col *= 1. - uVig * pow(r*1.15, 2.3);             // vignette
```

* **A true 3D LUT is optional.** A 16x16x16 strip LUT costs one extra texture fetch. The analytic grade above does the same job without an asset and can be keyframed per time of day.

## 5. UI language

Black top and bottom bars, amber (`#f2b04a`) heavy italic numerals (Chakra Petch or Barlow Condensed), slanted clip-path plates with 3 px borders, and flat status bars (fuel, nitro, damage). No gradients or glows on plates. All of it lives in `01-ui.html` as CSS variables (`--tb`, `--hb`, safe-area pads).

## 6. Mobile shader rules used throughout

1. One draw call per prop variant (merge with `bake()`), and no per-frame allocation in `updateScenery`.
2. `precision` stays default `mediump` for sprites. All colour maths is plain arithmetic, with no dependent texture reads in the world shaders except the diffuse map.
3. No loops over lights. There is one directional, one fill and one hemisphere light.
4. Post passes run at or below the canvas size, and the bloom chain at a quarter.
5. Anything optional (shadow map, bloom pass, env probe) sits behind the quality tier and the `HQFX` guardrail.
6. Test on the slowest target at Med first: if it holds 60 fps there, High is a bonus.
