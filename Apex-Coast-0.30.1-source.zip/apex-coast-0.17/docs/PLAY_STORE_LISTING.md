# Google Play listing: Apex Coast

Everything below is ready to paste into Play Console. Character limits are Google's.

## Main store listing

**App name** (max 30): `Apex Coast: Endless Racing`

**Short description** (max 80):
`Endless coastal highway racing. Dodge traffic, drift, boost, collect supercars.`

**Full description** (max 4000):

```
Hit the coast road and race until the sun goes down.

APEX COAST is an endless arcade racer set on a tropical highway. Weave through traffic, take close passes for combo points, drift the long bends, and hit nitro when the road opens up. The light changes as you drive: golden sunset, purple dusk, a starry night, and back to a bright morning.

HOW IT PLAYS
• Simple touch controls: steer, brake, drift and nitro. Auto gas keeps you moving.
• Close passes and clean overtakes build your combo.
• Three game modes: Coast run, Time attack and Rush hour.
• Missions and a driver rank that grows as you play.

SEVEN CARS TO COLLECT
• Vesper, Kestrel, Mirage and Halcyon, each with its own look and nitro flame.
• Ember, Mamba and Solstice: orange supercar, cel-shaded outline racer and a short-wheelbase track special.
• Repaint every car and upgrade engine, handling and nitro.

LOOKS GREAT, RUNS OFFLINE
• Stylised low-poly world with palm trees, beach cafes, bunting and a changing sky.
• Quality levels for every phone, plus a frame-rate cap and motion blur you can switch off.
• No account, no ads, no pop-ups. Play anywhere, even without a signal.

Made by an independent developer, Mahfuz Rahman.

Car models: "(FREE) Racing Car in 3 styles" (https://skfb.ly/oLXFS) by Mena is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).
```

**Category:** Game > Racing
**Tags:** Racing, Arcade, Driving, Offline, Casual
**Contact email:** your support email (shown publicly)
**Privacy policy URL:** `https://github.com/rmdmahfuz727-sudo/Apex-Coast/blob/main/docs/PRIVACY_POLICY.md` (fill in your contact email in that file first)

## Graphics (all in `store/` and `branding/`)

| Slot | File | Spec |
|---|---|---|
| App icon | `store/icon-512.png` | 512 x 512 PNG |
| Feature graphic | `store/feature-graphic-1024x500.png` | 1024 x 500 |
| Phone screenshots | `store/screenshots/*.png` | 1920 x 1080 landscape, 16:9 (Play needs 2 to 8, longest side no more than 2x the shortest) |

Regenerate them with `python3 tools/build-web.py && node tools/store-shots.js`.

## App content answers

| Form | Answer |
|---|---|
| App or game | Game |
| Free or paid | Free |
| Ads | No ads |
| In-app purchases | None (credits are earned in play only) |
| App access | All functionality is available without login |
| Target audience | 13 and over is the simplest choice (avoids the Families programme rules). Younger is fine if you answer the Families questions |
| News app / government / health / finance | No |
| Content rating (IARC questionnaire) | Category "Game". No violence toward people or animals, no blood, no sexual content, no gambling, no user-generated content, no chat. Cars can crash in a cartoon way. Expect a low rating such as Everyone / PEGI 3 |

## Data safety form

The game itself collects and shares nothing.

| Question | Answer |
|---|---|
| Does your app collect or share any of the required user data types? | No |
| Is all of the user data encrypted in transit? | Not applicable |
| Do you provide a way for users to request data deletion? | Not applicable (all data is on the device; Settings > Reset progress or uninstall) |

One honest caveat: the display font is requested from Google Fonts when the phone is online, which sends the IP address to Google like any web request. If you want a bulletproof "no data" answer, bundle the Montserrat font files inside the app and remove the `INTERNET` permission from `AndroidManifest.xml`.

## Release steps

1. **Developer account.** Create it at play.google.com/console (one-time US$25). Verify your identity. Personal accounts created after 13 Nov 2023 must also run a **closed test with at least 12 testers opted in for 14 days in a row** before you can apply for production access (Google usually answers within 7 days).
2. **Signing key.** Run `tools/make-keystore.sh` once, add the four repository secrets it prints (see README), and keep the `.jks` file and passwords somewhere safe. This is your *upload key*. Let Play enrol the app in **Play App Signing** when you upload the first bundle.
3. **Build the bundle.** Push to GitHub and open the *Build Android APK and Play bundle* run. Download the **ApexCoast-play-bundle** artifact (`ApexCoast.aab`).
4. **Create the app** in Play Console (Game, Free) and fill in the store listing, graphics, privacy policy URL, content rating, data safety, target audience and ads declarations from this page.
5. **Testing track.** Upload `ApexCoast.aab` to *Closed testing*, add 12 or more testers' Google accounts (an email list), share the opt-in link and keep them opted in 14 days.
6. **Production.** Click *Apply for production*, answer the short questions about your test, and when approved, promote the release to Production.
7. **Every update.** Raise `versionCode` in `android/app/build.gradle` by at least 1, build a new bundle and upload it.

## Requirements this project already meets

- Android App Bundle build (`bundleRelease`).
- `targetSdk 36` (new apps and updates must target Android 16 from 31 Aug 2026, with an extension to 1 Nov 2026 where Google granted one).
- 64-bit by design (no native code).
- Adaptive and monochrome launcher icons.
- Credit for the CC BY car models in Settings, `THIRD_PARTY_NOTICES.md` and the listing text.

## Things to double-check yourself

- **Car designs.** Ember, Mamba and Solstice look very much like a real supercar. The manufacturer badge texture was removed and the game uses no brand names, but Play can still remove apps for intellectual property complaints. If you want to be safe, swap in an original model or rework the body shape.
- **Name.** Search Play and the trademark databases for "Apex Coast" before you publish; "Apex" is a common game word.
- **Policy dates.** Google changes Play rules often; read the Play Console prompts at submission time.
