# Apex Coast

A 3D endless coastal-highway racer for Android. Dodge traffic, drift, boost with nitro and chase a high score at sunset.

**Developed by Mahfuz Rahman**

The game is a WebGL page (three.js) wrapped in a small native Android app, so there is no Unity or large engine to install.

## Get the APK

The APK is built by GitHub Actions, not on your computer.

1. Push this repository to GitHub (see below).
2. Open the **Actions** tab. The *Build Android APK* workflow starts on every push to `main`.
3. When it finishes, open the run and download the **ApexCoast-apk** artifact (a zip containing `ApexCoast.apk`).
4. To publish a downloadable release, tag a version and push the tag:

   ```sh
   git tag v1.0.0
   git push origin v1.0.0
   ```

   The workflow attaches `ApexCoast.apk` to a new release under **Releases**.
5. On your phone, open the APK and allow installs from this source when Android asks.

### Push to GitHub

```sh
git remote add origin https://github.com/<your-username>/apex-coast.git
git push -u origin main
```

Create the empty repository on github.com first (no README, no licence).

### Optional: stable signing key

Without extra setup the APK is signed with a throwaway debug key. It installs fine, but a later build
cannot update an earlier install; you would uninstall first. To avoid that, run `tools/make-keystore.sh`
once (needs a JDK) and add the four secrets it prints under **Settings > Secrets and variables > Actions**.
Keep the generated `.jks` file private.

## Controls

| Action | Touch | Keyboard |
| --- | --- | --- |
| Steer / change lane | left and right buttons | arrow keys or A / D |
| Drift | Drift (hold while steering) | Space |
| Brake / reverse | Brake | Down or S |
| Nitro | Nitro | Shift (or N / E) |

The app locks to landscape. Press back once to pause, twice to exit.

## Project layout

- `game/src/` game source, split into UI, core, scene, cars and game logic
- `tools/build-web.py` assembles the game into `android/app/src/main/assets/`
- `android/` Gradle project (a single `MainActivity` hosting a WebView)
- `.github/workflows/build-apk.yml` the APK build

After editing anything in `game/src/`, run `python3 tools/build-web.py` and commit the regenerated assets.

## Build locally

Needs JDK 17 and the Android SDK (compile SDK 35).

```sh
python3 tools/build-web.py
cd android && ./gradlew assembleRelease
```

The APK lands in `android/app/build/outputs/apk/release/`.

## Beta 0.2.0

Polish pass focused on a safer, more professional mobile experience:
- Added a clear Beta 0.2.0 / Coastline Series label on the main menu.
- Improved touch-target sizing and keyboard focus visibility for buttons.
- Added subtle hover feedback for pointer devices without changing driving mechanics.
- Respects the operating system's reduced-motion preference.
- Kept the existing gameplay, saved progress key, car data, and graphics settings intact.

## Notes

- The game runs fully offline. The app asks for the internet permission only so the Google Fonts stylesheet can load; offline it uses system fonts.
- Third-party licences are listed in `THIRD_PARTY_NOTICES.md`. No licence has been chosen for this project's own code yet; add one that suits you.

## Beta 0.3.0 — Coastline & driving feel

- Added subtle animated sea-surface glints using the existing water shader (no extra scene objects or draw calls).
- Refined sunset lighting with a softer cool fill to improve contrast on cars and roadside scenery.
- Smoothed chase-camera position and aim, with low-amplitude periodic shake instead of frame-by-frame random jitter.
- Reduced default render resolution on mobile quality presets and made adaptive resolution respond sooner to slow frame rates.
- Kept the existing controls, save data format, package ID, and gameplay systems unchanged.

The updated source still needs a GitHub Actions build and on-device testing across the available quality settings. On-device frame rate depends on the phone, thermal state, and graphics setting.


## Beta 0.4.0 — Sunset Coast & Supercar Detail

- Brighter golden-hour lighting, warmer sand, and a clearer turquoise ocean palette.
- Added lightweight hood accents, side sill highlights, vents, rear diffuser fins, and a motorsport rear wing on the player coupe.
- Increased car-paint clearcoat and reflection response while keeping the new detail geometry intentionally low-cost for mobile GPUs.

This is a source update. Build and test with GitHub Actions before distributing the APK; performance and appearance still need validation on target phones.


## Beta 0.5.0 — Coastal Materials & Presentation

This visual pass adds generated-on-device asphalt wear and fine seams, procedural sand and terrain detail, richer building facades with floor bands and lit windows, and more polished glass-like HUD panels and touch feedback. Player-car clearcoat response is slightly stronger. Textures are generated locally at runtime; no external image downloads are required.

**Validation note:** source changes are prepared for the existing GitHub Actions workflow. Build and test the APK on a physical device before treating this beta as release-ready.


## Beta 0.6.0 — Surface detail, cars & developer credits

- Added more layered procedural asphalt grain, worn patches, hairline cracks and reflective micro-speckle to the road texture.
- Improved building facade textures with clearer recessed windows, floor bands, balcony rails, concrete grain and varied warm-lit windows.
- Added small brake calipers, mirror housings and rear-deck louvres to sportier cars while keeping geometry procedural and lightweight.
- Added a clickable developer GitHub profile link to the Settings credit panel: https://github.com/rmdmahfuz727-sudo
- Kept the game offline-capable and used procedural canvas textures rather than remote image assets.


## Beta 0.8.0 — Tropical coastline art direction

- Replaced the distant high-rise skyline with merged low-poly island and headland silhouettes.
- Changed roadside architecture to smaller coastal resort buildings with warm stucco tones and softer window glow.
- Shifted road-side barriers and accent lighting from strong neon to warm coastal materials.
- Added recycled low-poly coastal rocks and scrub clusters using shared geometry to keep object creation bounded.
- Refreshed the menu palette for a brighter sunset-coast identity while retaining existing menu controls and developer GitHub credit.
- Bumped Android versionCode/versionName to 7 / 0.8.0.

**Scope note:** The current game uses Three.js r128 with procedural geometry. This pass improves its existing environment and presentation without introducing external asset downloads or replacing the working driving/traffic systems. The road path remains the existing straight endless-road gameplay layout; a fully curved coastal route would require coordinated changes to road mesh, vehicle movement, traffic, collisions, and camera pathing.


## Beta 0.8.0 — Natural Tropical Coast

Replaces the synthwave/neon presentation with a warm, open tropical sunset palette, a continuous sun disc, subdued natural materials, low resort villas, and a cleaner coastline horizon. The existing driving and UI flows are retained.


## Beta 0.10.0 — stylized coastal graphics pass

This graphics-only update takes broad inspiration from the readable, low-poly scenic presentation of endless-driving games while preserving Apex Coast's original tropical sunset identity and gameplay. It warms the asphalt and roadside palette, reduces excessive metallic/neon-like reflections and underglow, and updates default car paints and interface styling. No driving physics, scoring, progression, or controls were intentionally changed.


## Beta 0.11.0 — coastal scenery detail pass

- Added recycled low-poly beach-detail clusters with dune grass, pebbles, and driftwood on the sandy coast and grass verge.
- Shared vertex-coloured geometry/materials keep each cluster to one draw call.
- New scenery follows the existing scrolling/recycling system and is reduced by the existing decoration quality setting.
- Driving, controls, scoring, and progression code were not intentionally changed.
- Android versionCode/versionName: 11 / 0.11.0.


## Beta 0.15.0 — coastal visual and interface refresh

- Refined the menu, garage, settings, pause, and game-over surfaces with a consistent modern coastal motorsport UI, clearer contrast, rounded glass-like panels, and thumb-friendly controls.
- Updated the visible beta label and Android version to 0.15.0 (versionCode 14).
- Added warm reflector details to the existing shared guardrail geometry and enabled ACES tone mapping for a more cohesive sunset/coastal color response.
- Kept the existing ocean shader, layered islands, coastline, mountains, palms, beach details, car models, controls, driving physics, scoring, and progression systems.
- Intended for mobile performance: shared geometry/materials are retained and no external art downloads are required.
- Validation: source assembly and JavaScript syntax checks are run for this package; a physical-device APK/visual test is still required before release.


## Beta 0.15.0 visual pass
- Increased Ultra rendering resolution and reflection-capture resolution.
- Added merged low-poly coastal rock shelves and dune shrubs.
- Refined coastal lighting, sunset cloud contrast, and the modern motorsport UI.
- Gameplay logic and control bindings are intentionally unchanged.

## Beta 0.16.0 — town dressing & driver licence
- Added bunting strung across the road and recycled market stalls with striped awnings along the left verge.
- Added a Driver screen: editable name, drives, distance, cars owned, best score and an avatar picker (saved in the existing save data).
- Driving, scoring and controls unchanged. Needs on-device testing.

## Beta 0.17.0 — fuel, damage, drive modes
- Fuel and damage HUD: fuel drains (faster on nitro; engine cuts at empty), traffic hits add damage and the run ends when damage is full.
- Drive button opens mode cards: Coast Run, Zen Drive (no fuel or damage) and Dusk Run (dimmer light, double credits, unlocks at 1,500 best).
- Garage cards show a Fuel bar. Added banana plants and balcony townhouses along the left verge.
