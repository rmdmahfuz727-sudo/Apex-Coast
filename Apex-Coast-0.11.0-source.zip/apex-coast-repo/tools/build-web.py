#!/usr/bin/env python3
"""Assemble the game from game/src into the Android app's assets (index.html + three.min.js)."""
import pathlib, shutil, sys

root = pathlib.Path(__file__).resolve().parent.parent
assets = root / "android" / "app" / "src" / "main" / "assets"
parts = sorted((root / "game" / "src").glob("0*.html"))
if not parts:
    sys.exit("no source parts found in game/src")

body = "".join(p.read_text(encoding="utf-8") for p in parts)
cdn = '<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>'
if cdn not in body:
    sys.exit("three.js script tag not found in game/src")
body = body.replace(cdn, '<script src="three.min.js"></script>')

head = (
    '<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n'
    '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">\n'
    "<style>[hidden]{display:none!important}body{margin:0}</style>\n"
)
assets.mkdir(parents=True, exist_ok=True)
(assets / "index.html").write_text(head + body + "\n</body>\n</html>\n", encoding="utf-8")
shutil.copyfile(root / "game" / "vendor" / "three.r128.min.js", assets / "three.min.js")
print(f"wrote {assets/'index.html'} ({(assets/'index.html').stat().st_size:,} bytes)")
