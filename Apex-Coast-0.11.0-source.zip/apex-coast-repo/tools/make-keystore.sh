#!/bin/sh
# Creates a signing key once, so every APK you publish can update the previous install.
# Needs a JDK (keytool). Keep the .jks file and passwords private; never commit them.
set -e
KS=apexcoast-release.jks
ALIAS=apexcoast
printf "Choose a keystore password (6+ characters): "; stty -echo; read PASS; stty echo; echo
keytool -genkeypair -v -keystore "$KS" -alias "$ALIAS" -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass "$PASS" -keypass "$PASS" -dname "CN=Mahfuz Rahman, O=Apex Coast"
echo
echo "Add these four repository secrets (Settings > Secrets and variables > Actions):"
echo "  ANDROID_KEYSTORE_PASSWORD = the password you typed"
echo "  ANDROID_KEY_PASSWORD      = the same password"
echo "  ANDROID_KEY_ALIAS         = $ALIAS"
echo "  ANDROID_KEYSTORE_BASE64   = the text printed below"
echo
base64 -w0 "$KS" 2>/dev/null || base64 "$KS"
echo
