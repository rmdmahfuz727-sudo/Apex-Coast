# Third-party notices

## three.js (r128)
Bundled as `game/vendor/three.r128.min.js` and copied into the app. MIT licensed.
Full licence text: `game/vendor/THREE_LICENSE.txt`.

## Fonts
The game loads Chakra Petch and Barlow Condensed from Google Fonts when the phone is online
(both under the SIL Open Font License 1.1). Offline, it falls back to system fonts.
