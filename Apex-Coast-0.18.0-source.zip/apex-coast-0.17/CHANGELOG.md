# Changelog

## 0.18.0

- Roadside detail pass: graffiti jersey barriers replace the guardrails, tall solar street lamps with glowing heads, large foreground palms,
  agave, saguaro and barrel cactus clusters with pink-flower shrubs, neon shop signs (Motel, Arcade, Diner, Surf shop and more) on the buildings,
  a beach bar with string lights, parasols and surfboards on the sand, vending machines, bus shelters and benches.
- Sky: sun spikes around the disc. Road: long tyre skid arcs.
- Version 0.18.0 (versionCode 19).

## 0.17.1

- Removed the duplicate Profile and Modes icons from the main menu top bar and the Profile side tab. Profile opens from the rank plate (top right), Modes from the Modes tab.
- Version 0.17.1 (versionCode 18).

## 0.17.0

- Hub-style main menu: icon row (settings), rank plate with avatar, slanted Modes and Profile tabs, mission card, big Start button.
- New Modes screen with cards: Coast run, Time attack (unlocks at 3,000 best) and Rush hour (unlocks at 8,000 best), plus a Zen switch (no crashes, no score).
- New Driver profile: editable name on a licence card, lifetime stats, six original helmet avatars unlocked by rank.
- Lifetime missions (overtakes and close calls) pay credits; each run has pass goals that pay a bonus.
- In-run HUD redesigned: letterbox bars, large slanted pause, driver plate with score, bottom bar with combo, nitro and distance-versus-record gauges, outlined captions.
- Garage shows the neighbouring cars as a dim lineup on a pedestal, full stat names and a level badge.
- Per-mode records; results screen names the mode and lists mission and goal rewards.
- Version 0.17.0 (versionCode 17).

## 0.16.0

- New interface in a dark charcoal and amber style: letterbox top and bottom bars, slanted plates, heavy italic type.
  Rebuilt the main menu, garage, settings, pause, results, HUD and touch controls.
- Garage: preview any car before buying, stat bars, Cars / Paint / Tune tabs, previous and next buttons, one Select / Buy button.
- Driver rank on the main menu (Rookie to Legend) based on your best score, plus runs and longest drive.
- Short landscape phones (about 360 px tall) and portrait layouts no longer clip.
- Performance: busy-traffic draw calls cut from about 840 to about 420 (merged guardrail, rock and shrub meshes,
  single-material traffic wheels, merged car bodies, hidden brake glow, cached car geometry).
- Player cars get a livery (flank blades, hood and deck ribbons, brake calipers) and every car casts a soft sun shadow.
- Version 0.16.0 (versionCode 16).

## 0.15.0

Coastal visual and interface refresh: ACES tone mapping, warm guardrail reflectors, low-poly rock shelves and dune shrubs,
higher Ultra render resolution.

## 0.11.0 – 0.14.0

Beach-detail clusters (dune grass, pebbles, driftwood), stylised coastal graphics pass, softer car paint and underglow.

## 0.8.0 – 0.10.0

Natural tropical palette replaces the neon look. Merged island silhouettes, coastal resort buildings, recycled rocks and scrub.

## 0.2.0 – 0.6.0

Beta label, touch-target and focus polish, smoother chase camera, sea glints, procedural asphalt and facade textures,
more detailed cars, developer credit with GitHub link in Settings.
