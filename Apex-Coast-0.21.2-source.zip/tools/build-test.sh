#!/bin/sh
# Local test page: same wrapper as the Android build, but keeps the CDN three.js tag so test tools can intercept it.
cd "$(dirname "$0")/.." || exit 1
mkdir -p .tmp
{ printf '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><style>[hidden]{display:none!important}body{margin:0}</style>'; cat game/src/0*.html; printf '</body></html>'; } > .tmp/test.html
wc -c .tmp/test.html
