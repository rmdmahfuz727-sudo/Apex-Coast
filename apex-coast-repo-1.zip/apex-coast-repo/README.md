# Apex Coast

A 3D endless coastal-highway racer for Android. Dodge traffic, drift, boost with nitro and chase a high score at sunset.

**Developed by Mahfuz Rahman**

The game is a WebGL page (three.js) wrapped in a small native Android app, so there is no Unity or large engine to install.

## Get the APK

The APK is built by GitHub Actions, not on your computer.

1. Push this repository to GitHub (see below).
2. Open the **Actions** tab. The *Build Android APK* workflow starts on every push to `main`.
3. When it finishes, open the run and download the **ApexCoast-apk** artifact (a zip containing `ApexCoast.apk`).
4. To publish a downloadable release, tag a version and push the tag:

   ```sh
   git tag v1.0.0
   git push origin v1.0.0
   ```

   The workflow attaches `ApexCoast.apk` to a new release under **Releases**.
5. On your phone, open the APK and allow installs from this source when Android asks.

### Push to GitHub

```sh
git remote add origin https://github.com/<your-username>/apex-coast.git
git push -u origin main
```

Create the empty repository on github.com first (no README, no licence).

### Optional: stable signing key

Without extra setup the APK is signed with a throwaway debug key. It installs fine, but a later build
cannot update an earlier install; you would uninstall first. To avoid that, run `tools/make-keystore.sh`
once (needs a JDK) and add the four secrets it prints under **Settings > Secrets and variables > Actions**.
Keep the generated `.jks` file private.

## Controls

| Action | Touch | Keyboard |
| --- | --- | --- |
| Steer / change lane | left and right buttons | arrow keys or A / D |
| Drift | Drift (hold while steering) | Space |
| Brake / reverse | Brake | Down or S |
| Nitro | Nitro | Shift (or N / E) |

The app locks to landscape. Press back once to pause, twice to exit.

## Project layout

- `game/src/` game source, split into UI, core, scene, cars and game logic
- `tools/build-web.py` assembles the game into `android/app/src/main/assets/`
- `android/` Gradle project (a single `MainActivity` hosting a WebView)
- `.github/workflows/build-apk.yml` the APK build

After editing anything in `game/src/`, run `python3 tools/build-web.py` and commit the regenerated assets.

## Build locally

Needs JDK 17 and the Android SDK (compile SDK 35).

```sh
python3 tools/build-web.py
cd android && ./gradlew assembleRelease
```

The APK lands in `android/app/build/outputs/apk/release/`.

## Notes

- The game runs fully offline. The app asks for the internet permission only so the Google Fonts stylesheet can load; offline it uses system fonts.
- Third-party licences are listed in `THIRD_PARTY_NOTICES.md`. No licence has been chosen for this project's own code yet; add one that suits you.
