# Changelog

## 0.23.1

- Fixed rocks and plant clusters that could spawn on or overlap the road. A scan of every recycled prop over thousands of metres now finds nothing standing in the driving lanes (street-lamp arms and tall palm crowns still reach over the road high up, by design).
- Version 0.23.1 (versionCode 27).

## 0.23.0

- Premium UI motion: every screen now animates in (top and bottom bars slide, content rises, cards and rows stagger), and a slanted amber wipe sweeps between screens and into a run.
- Press feedback on all buttons (squish and spring back), a slow sheen across the Start and Drive buttons, and credit and best-score counters that count up.
- Results: the score counts up, the stat rows stagger in, and the New record badge stamps in with a glow.
- Garage: stat bars fill from the left and the car name slides in the direction you swipe.
- HUD: combo and objective counters pop when they change, and the nitro bar pulses while boosting.
- Everything uses transform and opacity only, and is switched off by the system "reduce motion" setting.
- Version 0.23.0 (versionCode 26).

## 0.22.0

- Stylised low-poly look inspired by #DRIVE: every prop is flat-shaded (faceted), world lighting is quantised into soft cel bands, and fog is much heavier (purple haze at night, warm haze at sunset) so distant scenery fades out.
- Film grade: crushed blacks, cool shadows and warm highlights, finer film grain, grade keyed to time of day.
- High and Ultra: a proper downscaled bloom (bright-pass, separable blur) for the sun, lamps and neon, and a real soft shadow for the player car. If the frame rate collapses, the game drops these first.
- New #DRIVE-style props: coloured bunting strung across the road, painted casas with balconies and warm lit windows at night, and crate-and-barrel stalls with striped awnings.
- Motion blur: speed-based zoom blur toward the vanishing point that grows with speed and nitro and leaves your car sharp. Settings has a Motion blur On/Off switch (needs Medium or higher).
- Removed the chromatic aberration (colour fringing) effect from nitro and crashes.
- Asphalt now has a sky sheen and a sun or moon glitter path.
- New docs/GRAPHICS_GUIDE.md describing the whole pipeline with code.
- Version 0.22.0 (versionCode 25).

## 0.21.2

- Barrier graffiti: the tags used to straddle the crease where the barrier's lower slope meets the upper slope, so the lettering looked bent and overlapped. Tags now sit entirely on the flat upper face, are drawn at twice the resolution, and are smaller so words no longer crowd each other.
- Camera near plane moved from 0.3 to 0.6 for better depth precision, which reduces flicker on distant surfaces.
- Version 0.21.2 (versionCode 24).

## 0.21.1

- Fixed the big circular rainbow glare and dark blob in the sky: the colour grade overshot on very bright pixels. Colours are now clamped, bloom only picks up true highlights, and the sharpening filter is limited so it cannot ring.
- Daytime sky is a deeper blue with a softer sun glow.
- Version 0.21.1 (versionCode 23).

## 0.21.0

- Fixed palms and plants growing on or over the road: trees now stand clear of the road edge, including their leaning trunks and fronds.
- Graphics quality: higher render resolution on Medium, High and Ultra (the adaptive scaler still protects the frame rate), sharpening filter, light bloom on Medium, full texture filtering on buildings and signs, soft ground shading on every prop, and fuller palm crowns.
- Version 0.21.0 (versionCode 22).

## 0.20.0

- Day and night cycle: a full cycle takes 5 minutes (sunset, dusk, night, dawn, day, golden hour). The sky, fog, ocean, lights and exposure all follow it.
- Night: stars and a crescent moon, lit building windows, brighter street-lamp and beach-bar glow, full-strength neon signs and a headlight beam on the road. Signs dim a little in daylight.
- New Settings row "Time": Auto (cycle), Day, Sunset or Night.
- Version 0.20.0 (versionCode 21).

## 0.19.0

- Concept-sheet assets: sand, stucco, wood-plank and corrugated-metal textures cut from your sheet now cover the ground and the SUNTEE café / gas station (stucco walls, wood shed, metal door and canopy).
- New props: MOTEL pole signs with green L-bracket neon and VACANCY, SUNTEE multicolour neon rooftop sign, Synthwave / Lightning / Fire-boost car liveries with side decals.
- Nitro effects per car: neon magenta-cyan trail (Kestrel), blue-white electric arcs (Mirage), fat orange fire boost (Halcyon), classic blue flame (Vesper).
- Denser roadside: more palms, plants, rocks, beach clutter, near buildings, vending kits, cafes and motel signs. Draw calls about 490 on Medium (was 575 in 0.6.0).
- Version 0.19.0 (versionCode 20).

## 0.18.0

- Roadside detail pass: graffiti jersey barriers replace the guardrails, tall solar street lamps with glowing heads, large foreground palms,
  agave, saguaro and barrel cactus clusters with pink-flower shrubs, neon shop signs (Motel, Arcade, Diner, Surf shop and more) on the buildings,
  a beach bar with string lights, parasols and surfboards on the sand, vending machines, bus shelters and benches.
- Sky: sun spikes around the disc. Road: long tyre skid arcs.
- Version 0.18.0 (versionCode 19).

## 0.17.1

- Removed the duplicate Profile and Modes icons from the main menu top bar and the Profile side tab. Profile opens from the rank plate (top right), Modes from the Modes tab.
- Version 0.17.1 (versionCode 18).

## 0.17.0

- Hub-style main menu: icon row (settings), rank plate with avatar, slanted Modes and Profile tabs, mission card, big Start button.
- New Modes screen with cards: Coast run, Time attack (unlocks at 3,000 best) and Rush hour (unlocks at 8,000 best), plus a Zen switch (no crashes, no score).
- New Driver profile: editable name on a licence card, lifetime stats, six original helmet avatars unlocked by rank.
- Lifetime missions (overtakes and close calls) pay credits; each run has pass goals that pay a bonus.
- In-run HUD redesigned: letterbox bars, large slanted pause, driver plate with score, bottom bar with combo, nitro and distance-versus-record gauges, outlined captions.
- Garage shows the neighbouring cars as a dim lineup on a pedestal, full stat names and a level badge.
- Per-mode records; results screen names the mode and lists mission and goal rewards.
- Version 0.17.0 (versionCode 17).

## 0.16.0

- New interface in a dark charcoal and amber style: letterbox top and bottom bars, slanted plates, heavy italic type.
  Rebuilt the main menu, garage, settings, pause, results, HUD and touch controls.
- Garage: preview any car before buying, stat bars, Cars / Paint / Tune tabs, previous and next buttons, one Select / Buy button.
- Driver rank on the main menu (Rookie to Legend) based on your best score, plus runs and longest drive.
- Short landscape phones (about 360 px tall) and portrait layouts no longer clip.
- Performance: busy-traffic draw calls cut from about 840 to about 420 (merged guardrail, rock and shrub meshes,
  single-material traffic wheels, merged car bodies, hidden brake glow, cached car geometry).
- Player cars get a livery (flank blades, hood and deck ribbons, brake calipers) and every car casts a soft sun shadow.
- Version 0.16.0 (versionCode 16).

## 0.15.0

Coastal visual and interface refresh: ACES tone mapping, warm guardrail reflectors, low-poly rock shelves and dune shrubs,
higher Ultra render resolution.

## 0.11.0 – 0.14.0

Beach-detail clusters (dune grass, pebbles, driftwood), stylised coastal graphics pass, softer car paint and underglow.

## 0.8.0 – 0.10.0

Natural tropical palette replaces the neon look. Merged island silhouettes, coastal resort buildings, recycled rocks and scrub.

## 0.2.0 – 0.6.0

Beta label, touch-target and focus polish, smoother chase camera, sea glints, procedural asphalt and facade textures,
more detailed cars, developer credit with GitHub link in Settings.
